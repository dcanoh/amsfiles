30/12/2014

Para modificar el dise�o de la aplicaci�n necesita tener instalado 
Autoplay Media Studio 8.1
Para modificar el codigo fuente utilice cualquier editor de texto y 
visualice los archivos *.lua

Dedicado a todos los users de AMSSPECIALIST

Hern�n Dar�o Cano Hern�ndez - thdkano[at]gmail[dot]com
-------------------------------------------------------
amsspecialist.com 			-	 thedary.tumblr.com