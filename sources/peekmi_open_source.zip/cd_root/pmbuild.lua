sReleaseFolder = _SourceFolder.."\\release"

if Folder.DoesExist(sReleaseFolder) then
	File.Run("cmd.exe", '/k "rmdir /Q /S release & exit', _SourceFolder, SW_HIDE, true)
end

Folder.Create(sReleaseFolder)
--Folder.Create(sReleaseFolder.."\\clibs")
Folder.Create(sReleaseFolder.."\\data")

File.Copy(_SourceFolder.."\\*.*", sReleaseFolder.."\\", false, true, false, true, nil)
--File.Copy(_SourceFolder.."\\clibs\\*.*", sReleaseFolder.."\\clibs\\", true, true, false, true, nil)
File.Copy(_SourceFolder.."\\data\\*.*", sReleaseFolder.."\\data\\", true, true, false, true, nil)
File.Copy(_SourceFolder.."\\pm_files\\default_passmaster.db", sReleaseFolder.."\\data\\passmaster.db", true, true, false, true, nil)

File.Run("cmd.exe", '/k "del /Q /F *.lua *.gitignore & exit"', sReleaseFolder, SW_HIDE, true)

File.Delete(sReleaseFolder.."\\*.lua* *.gitignore*")

sFolder = sReleaseFolder.."\\lua"

tFound = File.Find(sFolder, "*.lua", true, false)

if tFound then
	for i, sPath in ipairs(tFound) do
		tPath 	 = String.SplitPath(sPath)
		sNewFile = "data\\"..tPath.Filename..".luac"
		sOldFile = "data\\"..tPath.Filename..tPath.Extension
		File.Run("pm_files\\luac.exe", "-o "..sNewFile.." "..sOldFile, sReleaseFolder, SW_HIDE, true)	
		Application.Sleep(33)
		File.Delete(sPath, true, false, true, nil)
	end
end

-- Compilar las librerias de PeekMi

File.Run("pm_files\\luac.exe", "-o data\\luaf.bin data\\luaf.lua", sReleaseFolder, SW_SHOWNORMAL, true)
Application.Sleep(700)
File.Delete(sReleaseFolder.."\\data\\luaf.lua", true, false, true, nil)
-----------------------------------

sFolder = sReleaseFolder.."\\data"

tFound = File.Find(sFolder, "*.lua", true, false)

if tFound then
	for i, sPath in ipairs(tFound) do
		tPath 	 = String.SplitPath(sPath)
		sNewFile = "data\\"..tPath.Filename..".lib"
		sOldFile = "data\\"..tPath.Filename..tPath.Extension

		File.Run("pm_files\\luac.exe", "-o "..sNewFile.." "..sOldFile, sReleaseFolder, SW_HIDE, true)	
		Application.Sleep(33)
		File.Delete(sPath, true, false, true, nil)
	end
end

TextFile.WriteFromString(sReleaseFolder.."\\setupver", File.GetVersionInfo(sReleaseFolder.."\\peekmi.exe").FileVersion, false)

File.Rename(sReleaseFolder.."\\data\\luaf.bin", sReleaseFolder.."\\data\\luaf.lua")

Zip.Add("release.zip", {sReleaseFolder.."\\*.*"}, true, "", 9, nil, true)

File.Copy(_SourceFolder.."\\pm_files\\setup.exe", sReleaseFolder.."\\setup.exe", true, true, false, true, nil)

File.Run("pm_files\\rar.exe", '/k  a -ep -m5 setup.exe "'..sReleaseFolder..'\\setupver" "'.._SourceFolder..'\\license.txt" '..sReleaseFolder..'\\release.zip"', sReleaseFolder, SW_SHOWNORMAL, true)

Mensaje("Compilacion terminada!", "PeekMi esta compilado y puede ser distribuido al publico.");
