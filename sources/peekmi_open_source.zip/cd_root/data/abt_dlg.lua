ABOUT = {
	OnPreload = function (this)
		lang.set()
		Paragraph.SetText("version_pg", tLang.ABOUT.version_pg.." "..sVERSION)
	end,
	
	OnShow = function (this)
		-- body
	end,
	
	OnTimer = function (e_ID)
		-- body
	end,
	
	OnKey = function (e_Key, e_Modifiers)
		-- body
	end,

	OnClose = voidf

}

about_cerrar = {
	OnClick = function(this)
		cerrar.OnLeave(this)
		DialogEx.Close()
	end,
}

moreinfo_pg = {
	OnClick = function(this)
		--File.OpenURL("http://peekmi.tumblr.com/disclaimer")
		File.Open("license.txt")
	end,
}