-- CARGAR MODULOS:
Application.LoadActionPlugin("data\\dsocket.lib");
------------------

sUpdateFolder = _SourceFolder.."\\updates"
sVerifyFile = sUpdateFolder.."\\pm_info.dat"	
sUpdateFile = sUpdateFolder.."\\pm_update.zip"

local tServers = {
	"http://dl.dropboxusercontent.com/u/7542442/PeekMi/pm_info.dat",
	"http://127.0.0.1/peekmi/pm_info.dat",
}

if File.DoesExist("pm_update.lua") then
-- Iniciar el script de instalacion	
	dofile("pm_update.lua")
end

function updatescript()
	sVERSION = "1.0.0.1"

	SaveSettings({is_updated  = true, last_update = System.GetDate(DATE_FMT_JULIAN)})

	File.Run("cmd.exe", '/k "ping 1.1.1.1 -n 1 -w 777 & updates\\stampver.exe -f'..sVERSION..' peekmi.exe & peekmi.exe & exit"', _SourceFolder, SW_HIDE)
	-- Un Mensaje con tiempo... timed message
	os.remove("updates\\pm_update.lua")
	os.exit()
end

PM.Update = {
	
	ZipExtractCB = function (String, Percent, Status)
		 if Status ==  ZIP_STATUS_MAJOR then
		 	local Percent = math.floor((Percent / 3) + 32)
			
			Application.Sleep(50)					 	
		 	
		 	PM.Progreso("progreso", Percent, tLang.Verificando)
		 end
	end,

	FileCopyCB = function(Source, Destination, Copied, Total, FileCopied, FileTotal)
		local Percent = (Copied / Total) * 100
		local Percent = math.floor((Percent / 3) + 66)
	
		Application.Sleep(50)
	
		PM.Progreso("progreso", Percent, tLang.Instalando)
	end
}

function PM.Update.Verify() -- table {Version, FileURL, FileMD5} or nil
	-- Testeamos la coneccion a cada uno de los servidores
		for n = 1, #tServers do
			bConnected = HTTP.TestConnection(tServers[n], 20, 80, nil, nil);

			if bConnected then
				sServer = tServers[n]
				break
			end
		end

		if bConnected then
			os.remove(sVerifyFile)
			HTTP.Download(sServer, sVerifyFile)
			return {
					Version    = INIFile.GetValue(sVerifyFile, "pm_update", "new_ver"),
					FileURL    = INIFile.GetValue(sVerifyFile, "pm_update", "new_url"),
					FileMD5	   = INIFile.GetValue(sVerifyFile, "pm_update", "new_md5"),
					Compatible = INIFile.GetValue(sVerifyFile, "pm_update", "new_com"),
				}
		else
			return nil
		end
end

function PM.Update.Download(sLink, sWebMD5)
      	local sLocalMD5 = Crypto.MD5DigestFromFile(sUpdateFile)

    -- Si son diferentes es porque no existe el archivo o porque el que existe esta corrupto, descargamos la actualizacion
      	if sWebMD5 ~= sLocalMD5 then
      		-- Definimos los argumentos para la descarga
      		sUserAgent, sHeaders, tProxy = "", "", nil
      		bResume, Data, ExData = false, "pm_info", ""
      		Session = Download.Start(Application.GetWndHandle(), sLink, sUpdateFile, sUserAgent, sHeaders, false, tProxy, 2, Data, ExData)	
      	end	
end

function PM.Update.Install(sObjeto) -- bool, str
	-- Comparamos Checksums y devolvemos un booleano   
	   	sWebMD5     = INIFile.GetValue(sVerifyFile, "pm_update", "new_md5")
	   	sLocalMD5   = Crypto.MD5DigestFromFile(sUpdateFile)
		sWebVersion = INIFile.GetValue(sVerifyFile, "pm_update", "new_ver")
		
		if sWebMD5 ~= sLocalMD5 then
		-- El archivo de actualización está corrupto
			PM.Progreso("progreso", 100)
			Folder.DeleteTree(sUpdateFolder)
			return false, tLang.errCorrupto
		else
			-- Creamos una carpeta de trabajo con el nombre de la versión de la actualización like "updates\\1300"
			local sWorkingFolder = sUpdateFolder.."\\"..sWebVersion:gsub("%.", "")
			Folder.Create(sWorkingFolder)

			Zip.Extract(sUpdateFile, {"*.*"}, sWorkingFolder, true, true, "", ZIP_OVERWRITE_ALWAYS, PM.Update.ZipExtractCB)

			--Paragraph.SetText(sObjeto.."_pg", tLang.Instalando)
			Application.Sleep(10)

			File.Copy(sWorkingFolder.."\\*.*", _SourceFolder.."\\", true, true, false, false, PM.Update.FileCopyCB) -- No incluye los archivos ocultos
			
			-- Test for error
			error = Application.GetLastError();
			if (error ~= 0) then
				Dialog.Message("Error", _tblErrorMessages[error], MB_OK, MB_ICONEXCLAMATION);
			end

			-- Establecemos el dia de la ultima actualizacion
			SaveSettings({last_update = System.GetDate(DATE_FMT_JULIAN)})
			PM.Progreso("progreso", 100)
			return true, "Exito"
		end
end



function Download.OnProgress(tblData)
	if (tblData ~= nil) then     
		if(tblData.ID == 2)then
			local Percent = math.floor(tblData.Percent / 3) -1
			
			Application.Sleep(50)
			
			PM.Progreso("progreso", Percent, tLang.Descargando)
		end
	end
end


function Download.OnError(tblData) 
	Download.Delete(tblData.Session);
end

function Download.OnComplete(tblData)
	
	if tblData.ID == 1 then
		--PM.Update(VERIFY, true)
		Download.Delete(tblData.Session);
	elseif tblData.ID == 2 then
		Download.Delete(tblData.Session)

		local bA, sE = PM.Update.Install("progreso")
		if not bA then
			-- Tiene algunos problemas pero eso es mientras testeo (Se muestra el mensaje la segunda vez de hacer clic en el boton test)
			
			-- MENSAJE DE ARCHIVO CORRUPTO mensaje(sE)
		end
	end
end

function PM.Update.Offline( ... )
	sUpdateFile = (arg[1])
	DialogEx.Show("UPDATING")
end

UPDATING = {

	OnPreload = function (this)
		lang.set(sLang)

	end,

	OnShow = function (this)
		-- Con esto podemos verificar algo:
			--for i, v in pairs (Zip.GetContents(_SourceFolder.."\\offline update._pmupd", true)) do
				-- ?
			--end
		Zip.Extract(sUpdateFile, {"*.*"}, _SourceFolder, true, true, "", ZIP_OVERWRITE_ALWAYS, 

			function (String, Percent, Status)
		 		if Status ==  ZIP_STATUS_MAJOR then		
					Application.Sleep(100)
		 	
		 			PM.Progreso("progreso", Percent, tLang.Instalando)
		 		end
		 	end)
		DialogEx.Close()
	end,

	OnClose = function (this)
		
	end,

	OnTimer = function (e_ID)

	end,

	OnKey = function (e_Key, e_Modifiers)
	
	end,

}