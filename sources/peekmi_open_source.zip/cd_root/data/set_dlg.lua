SETTINGS = {
	OnPreload = function (this)
		lang.set()


		-- PROBLEMAS CON ESTO
		Image.SetVisible("on_input", false)
		---------------------
		bUpdates = LoadSettings("updates")
		
		if bUpdates then
			CheckBox.SetChecked("updates_chk", true)
		else
			CheckBox.SetChecked("updates_chk", false)
		end

		if not(PM_drive)then
		    Paragraph.SetText("usb_pg", tLang.SETTINGS.EscogerLlave)
		    xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.Seleccionar, Enabled = false})
		else
			xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.NoConectada, Enabled = false})
		end
		
		PM.BorrarInputs()
		
		-- Ocultar Input de repetir y demás objetos
			Image.SetVisible("info_password_i", false)
			Image.SetVisible("contrasena3_inp_img", false)
			Input.SetVisible("contrasena3_inp", false)
			Paragraph.SetVisible("contrasena3_pg", false)
		--------------------------------------------------
		DialogEx.StartTimer(1, 1)
		DialogEx.StartTimer(1, 2)
	end,

	OnShow = function (this)
	-- Ocultar objetos
		ListBoxEx.SetVisible("dispositivos_list", false)
	   	Paragraph.SetVisible("dispositivos_box", false)
	   	Hotspot.SetEnabled("dispositivos_hs", false)
	--------------------------------------------------
		--DialogEx.ClickObject("refrescar_btn2")
		settings_refrescar_btn2.OnClick("refrescar_btn2")

	-- COMPATIBILIDAD CON LA BETA... (Default Pass)
	 	if PM_pass == "f58e0fd387f05747a19651f71672ef05" then
			Input.SetText("contrasena1_inp", "f58e0fd387f05747a19651f71672ef05")
			Input.SetEnabled("contrasena1_inp", false)
		end
		DialogEx.Redraw()
	end,

	OnTimer = function (e_ID)
		--[[if(e_ID == 1)then
			DialogEx.StopTimer(e_ID);
			if(DialogEx.GetFocus() == "contrasena1_inp")then
		       Image.SetPos("on_input", 15, 195);
			elseif(DialogEx.GetFocus() == "contrasena2_inp")then
		       Image.SetPos("on_input", 15, 239);
			elseif(DialogEx.GetFocus() == "contrasena3_inp")and(Input.IsVisible("contrasena3_inp"))then
			   Image.SetPos("on_input", 228, 239);
			else
		       Image.SetPos("on_input", -500,-500);
			end
			DialogEx.StartTimer(7, e_ID);
		end]]

		if(e_ID == 2)then
			DialogEx.StopTimer(e_ID);
			tDispositivosAnt  = tDispositivos;
			tDispositivos     = Drive.Enumerate();   
			sContrasena1 	  = Input.GetText("contrasena2_inp");
			sContrasena2 	  = Input.GetText("contrasena3_inp");
			bButton1,bButton2 = true, true;
			bVisible2 		  = false;
			bReboot  		  = false;

		   if(ContrasenaCoincide)then
		      nColor   = (nVerde);
		      sImagen  = (sf.IMGCorrecto);
		      sTexto   = (tLang.SETTINGS.PerfectoPass);
		      if(sContrasena1 == '')and(sContrasena2 == '')then
		      	 bButton1 = (false);
		      	 nColor   = (nNegro);
		      	 sImagen  = (sf.IMGAdvertencia);
		      	 sTexto   = (tLang.SETTINGS.RepetirPass); 
		      end
		   else
		      bButton1 = (false);
		      nColor   = (nRojo);
		      sImagen  = (sf.IMGProblema);
		      sTexto   = (tLang.SETTINGS.NoCoinciden);  
		      if(sContrasena2 == '')then
		         nColor  = (nNegro);
		         sImagen = (sf.IMGAdvertencia);
		         sTexto  = (tLang.SETTINGS.RepetirPass); 
		      end
		   end

		    -- Buscar cambios en los dispositivos extraibles del sistema
		    if(tdiff(tDispositivosAnt, tDispositivos) == true)then 
				settings_refrescar_btn2.OnClick("refrescar_btn2")
		    end
			
			-- Busco si el usuario escogio algun dispositivo
		    if sDispositivoSelect ~= '' and sDispositivoSelect then
		    	bVisible2 = true
		    	-- Si el archivo de configuracion requerido existe
		    	if File.DoesExist(sDispositivoRuta..sFileUSB) then
		            sImagen2 = (sf.IMGAdvertencia)
		            -- Suponemos que es otro dispositivo diferente a la llave
		            sTexto2  = (tLang.SETTINGS.YaUtilizado:gsub("$STR", sDispositivoNombre))
		            nColor2  = (nNegro)
		     		-- Habilitamos el boton de guardar
		     		bButton1 = true
		        
		        -- Si el archivo de configuracion requerido NO existe
		        else
		         	-- Vemos si es posible escribir en el dispositivo
		         	TextFile.WriteFromString(sDispositivoActual.."peekmi-test", "peekmi-test")
		         	if TextFile.ReadToString(sDispositivoActual.."peekmi-test") == "peekmi-test" then
			     		sImagen2 = (sf.IMGCorrecto);
			     		sTexto2	 = (tLang.SETTINGS.Compatible:gsub("$STR", sDispositivoNombre));
			     		nColor2  = (nVerde);
			     		-- Habilitamos el boton de guardar
			     		bButton1 = true
			     		--bButton2 = true
		         		File.Delete(sDispositivoActual.."peekmi-test")
		         	
		         	-- Si no es compatible
		         	else
			     		sImagen2 = (sf.IMGProblema);
			     		sTexto2	 = (tLang.SETTINGS.NoCompatible:gsub("$STR", sDispositivoNombre));
			     		nColor2  = (nRojo);
			     		-- Deshabilitamos el boton de guardar
			     		bButton1 = false
			     		--bButton2 = true		         		
		         	end
		    	end
		    -- Si no hay ningun dispositivo seleccionado
		    else
		    	-- DO ANYTHING
		    end

			Image.SetProperties("info_password_i",   {ImageFile = sImagen, Visible = bVisible});
			Paragraph.SetProperties("contrasena3_pg", {Text 		= sTexto , Visible = bVisible, ColorDisabled = nColor});

			Image.SetProperties("info_dispositivo_i",   {ImageFile = sImagen2, Visible = bVisible2});
			Paragraph.SetProperties("info_dispositivo", {Text 	   = sTexto2 , Visible = bVisible2, ColorDisabled = nColor2});
			xButton.SetEnabled("guardar_btn", bButton1)

			DialogEx.StartTimer(1, e_ID)
			DialogEx.Redraw()
		end
	end,
	
	OnKey = function (e_Key, e_Modifiers)
		--mensaje(e_Key)

	-- ESC
		if e_Key == 27 then
			settings_cerrar.OnClick("cerrar")
		end
	end,

	OnClose = voidf
}

settings_refrescar_btn2 = {
	OnClick = function ( ... )
			error = false
			nCount, nUSBs = 0, 0
			bUSBKey = false

			tDispositivosAnt = tDispositivos
			tDispositivos    = Drive.Enumerate()

			ListBoxEx.DeleteAllItems("dispositivos_list")

			sDispositivoSelect, sDispositivoNombre, sDispositivoSerial, sDispositivoRuta = '','','',''
			ListBoxEx.SelectNone    ("dispositivos_list")

			xButton.SetProperties("quitar", {Enabled = false, Visible = false})
			
			Paragraph.SetVisible("info_dispositivo", false)
			Image.SetVisible("info_dispositivo_i", false)

			repeat
				nCount = nCount + 1
				sDispositivoActual = (tDispositivos[nCount]) 
				tDispositivoAcInfo = Drive.GetInformation(sDispositivoActual)
				sArchivoContrasena = (sDispositivoActual..sFileUSB)

				if(tDispositivoAcInfo)then
					if(Drive.GetType(sDispositivoActual) == DRIVE_REMOVABLE)and(sDispositivoActual ~= "A:\\")then -- La constante DRIVE_REMOVABLE es igual a 2
					-- Si hay una llave USB declarada
						if PM_drive then
						-- Si existe el archivo de peekmi en el dispositivo
							if(File.DoesExist(sDispositivoActual.."\\"..sFileUSB))then
							-- Verificamos si es la llave de esta instalación
								sKey1   = Crypto.MD5DigestFromString(crypto(Drive.GetInformation(sDispositivoActual).SerialNumber, Drive.GetInformation(sDispositivoActual).SerialNumber, ENCODE))
								sKey2   = PM_drive
									
								if(sKey1 == sKey2)then 	  				
								    sContrasenaEncriptada = String.Replace(TextFile.ReadToString(sArchivoContrasena), 'DCano_PM7', '', true)
					            	sContrasena			  = crypto(sContrasenaEncriptada, Drive.GetInformation(sDispositivoActual).SerialNumber, DECODE)
									if(sContrasena == PM_pass)then
					             		bUSBKey = true
					             		sDispositivoRuta = sDispositivoActual
					                	--DialogEx.StartTimer(7, 20)
					                	break
									end
								else
								   --Paragraph.SetText("info_dispositivo", st.DispositivoUnaVez)
								end
							else
								--mensaje("NINGUN DISPOSITIVO")
							end
					-- Si no hay una llave USB declarada
						else
							nUSBs = nUSBs + 1
							PM.ComboAddItem('dispositivos', tDispositivoAcInfo.DisplayName, tDispositivoAcInfo.SerialNumber, sDispositivoActual)
						end
					end
				end
			until nCount == #tDispositivos
		
		-- Si la llave USB no está declarada
			if not PM_drive then
				xButton.SetVisible("quitar_btn", false)
			-- Si hay dispositivos usb conectados
				if nUSBs > 0 then
					Image.Load("usb_i", sf.IMGCorrectoUSB)
			        xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.Seleccionar,  Enabled = true})
			        Paragraph.SetEnabled("usb_pg", true) Image.SetOpacity("usb_i", 100)
			-- Si no hay dispositivos usb conectados
				else
					Image.Load("usb_i", sf.IMGProblemaUSB)
					xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.NoDisponible, Enabled = false})					
					Paragraph.SetEnabled("usb_pg", false) Image.SetOpacity("usb_i", 70)
				end
		-- Si la llave USB está declarada
			else
				
			-- Si la llave USB está conectada
				if bUSBKey then
					Image.SetOpacity("usb_i", 100)
					Paragraph.SetEnabled("usb_pg", true)
					xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.LlaveConectada, Enabled = true})  
					Image.Load("usb_i", sf.IMGCorrectoUSB)
					sDispositivoNombre = tDispositivoAcInfo.Label
					sDispositivoSerial = tDispositivoAcInfo.SerialNumber
					sDispositivoRuta   = sDispositivoActual
					xButton.SetProperties("quitar_btn", {Enabled = true, Visible = true})

			-- Si la llave USB NO está conectada
				else
					nUSBs = -1
					Image.SetOpacity("usb_i", 70)
					Paragraph.SetEnabled("usb_pg", false)
					xButton.SetProperties("dispositivos", {Text = tLang.SETTINGS.ConectarLlave, Enabled = false})
					Image.Load("usb_i", sf.IMGProblemaUSB)
					--sDispositivoRuta = ''

					error = tLang.SETTINGS.errConectarLlave --No puedes cambiar la contraseña de PeekMi sin tener la llave conectada
					xButton.SetProperties("quitar_btn", {Enabled = true, Visible = true})
					xButton.SetEnabled("guardar_btn", false)
				end
			end
		DialogEx.Redraw()
	end,
}

settings_dispositivos = {
	OnClick = function (this)
		if not bUSBKey then
			dispositivos.OnClick(this) 
		end
	end,
}

settings_contrasena2_inp = {
	OnKey = function (this, e_Key, e_Modifiers)
		if(Input.GetText(this)~= "")then
			Image.SetVisible("info_password_i", true)
			Image.SetVisible("contrasena3_inp_img", true)
			Input.SetVisible("contrasena3_inp", true)
			Paragraph.SetVisible("contrasena3_pg", true)
		else
			Image.SetVisible("info_password_i", false)
			Image.SetVisible("contrasena3_inp_img", false)
			Input.SetVisible("contrasena3_inp", false)
			Paragraph.SetVisible("contrasena3_pg", false)

		end

		if(Input.GetText(this) == Input.GetText("contrasena3_inp"))then
		     ContrasenaCoincide = true
		else
		     ContrasenaCoincide = false
		end
		
	end,
}

settings_contrasena3_inp = {
	OnKey = function (this, e_Key, e_Modifiers)
		if(Input.GetText(this) == Input.GetText("contrasena2_inp"))then
		    ContrasenaCoincide = true
		else
		    ContrasenaCoincide = false
		end

		if e_Key == 13 and xButton.IsEnabled("guardar_btn") then
			DialogEx.ClickObject("guardar_btn")
		end
	end,
}

settings_quitar_btn = {
	OnClick = function (this)
		local nMSG = Mensaje(tLang.SETTINGS.DesactivarLlave1, tLang.SETTINGS.DesactivarLlave2, PREGUNTA, sf.ADVER32)

		if nMSG then
			Paragraph.SetVisible("quitar_info_pg", false)
			database:delete(PMKEY, 2)
			os.remove(sDispositivoRuta..sFileUSB)
			PM_drive = nil
			USBKey = false
			DialogEx.ClickObject("refrescar_btn2")
		end
	end,

	OnEnter = function (this)
		Paragraph.SetVisible("quitar_info_pg", true)
	end,

	OnLeave = function (this)
		Paragraph.SetVisible("quitar_info_pg", false)
	end,
}

settings_dispositivos_list = {
	OnSelect = function (this, e_Index)
		sDispositivoSelect = (e_Index)
		sDispositivoNombre = ListBoxEx.GetItemText    ("dispositivos_list", e_Index, true)
		sDispositivoSerial = ListBoxEx.GetItemData    ("dispositivos_list", e_Index, true)
		sDispositivoRuta   = ListBoxEx.GetItemDataEx  ("dispositivos_list", e_Index, true)

		xButton.SetVisible("usb_reiniciar", false)

		if(Folder.DoesExist(sDispositivoRuta))then
		  if not(Folder.DoesExist(sDispositivoRuta..sFileUSB))then
		     sImagen = ("datos\\tema\\tick-small.png")
		     sTexto  = tLang.SETTINGS.Compatible:gsub('$DISPNAME', sDispositivoNombre)
		     nColor  = Math.HexColorToNumber("339966") -- Verde
		     usb_ok = (true)
		  else
		     sImagen = ("datos\\tema\\exclamation-small.png")
		     sTexto  = tLang.SETTINGS.YaUtilizado:gsub('$DISPNAME', sDispositivoNombre)
		     nColor  = Math.HexColorToNumber("333333") -- Negro
		     xButton.SetVisible("usb_reiniciar", true)
		     usb_ok = (true)
		  end
		else
		     sImagen = ("datos\\tema\\exclamation-small-red.png")
		     sTexto  = tLang.SETTINGS.NoCompatible:gsub('$DISPNAME', sDispositivoNombre)  
		     nColor  = Math.HexColorToNumber("993300") -- Rojo
		     usb_ok = (false)
		end

		Paragraph.SetProperties("info_dispositivo", {ColorDisabled = nColor, Text = sTexto})
		Image.Load("info_dispositivo_i", sImagen) Image.SetVisible("info_dispositivo_i", true)

		Paragraph.SetText("info_dispositivo"  , sTexto ) Paragraph.SetVisible("info_dispositivo"  , true)

		xButton.SetText(tostring(this):gsub('_list', ''), ListBoxEx.GetItemText(this, e_Index, true))
		e_ItemSel = ListBox.GetItemData(this, e_Index)

		xButton.SetState("dispositivos", BTN_UP)
		ListBoxEx.SetVisible(this, false)
		Paragraph.SetVisible("dispositivos_box", false)
		Hotspot.SetEnabled("dispositivos_hot", false)
		Page.SetFocus("WELCOME")

	end,
}

settings_updates_chk = {
	OnClick = function (this)
		if CheckBox.GetChecked(this) then
			SaveSettings({updates = true})
		else
			SaveSettings({updates = false})
		end
		Input.SetSelection("contrasena3_inp", 1, -1)
	end,
}

settings_guardar_btn = {
	OnClick = function (this)
		xButton.SetEnabled(this, false)
		if sDispositivoRuta then
			local sKeyFile = sDispositivoRuta..sFileUSB
		end
		local error, errormsg = false, false
		local sContrasenaAnterior = Input.GetText("contrasena1_inp");
		local sContrasena 		  = Input.GetText("contrasena2_inp");
		local query2 = ''
		local USBCFG, PASSCFG = false, false

		if sContrasena ~= '' and sContrasenaAnterior ~= '' and Input.GetText("contrasena3_inp") ~= '' then
			PASSCFG = true
			--mensaje(Input.GetText("contrasena2_inp"))
			--mensaje(Input.GetText("contrasena3_inp"))
			if(Input.GetText("contrasena2_inp") ~= Input.GetText("contrasena3_inp"))then
			-- Si las contraseñas no coinciden
				error    = tLang.SETTINGS.NoCoinciden
				errormsg = tLang.SETTINGS.NoCoinciden2:format(tLang.SETTINGS.contrasena1_pg, tLang.SETTINGS.contrasena2_pg)
				errortyp = ERRORMSG				
			elseif(sContrasenaAnterior ~= PM_pass)then
			-- Si la contraseña actual es incorrecta
				error 	 = tLang.SETTINGS.errContrasena
				errormsg = tLang.SETTINGS.errContrasena2
				errortyp = ERRORMSG
			end
		end

		if sDispositivoRuta and sDispositivoRuta ~= '' then
			USBCFG = true
			if not Drive.GetInformation(sDispositivoRuta) then
				error    = tLang.SETTINGS.errNoCompatible
				errormsg = tLang.SETTINGS.errNoCompatible2
				errortyp = ERRORMSG
			end
		else
			USBCFG = false
		end
	
	-- Si la llave USB está declarada y quiere hacer cambios en la contraseña, pero no esta conectada la llave
		if PM_drive and PASSCFG and not bUSBKey then
			error    = tLang.SETTINGS.NoSePuedeGuardar
			errormsg = tLang.SETTINGS.errConectarLlave
			errortyp = ADVERTEN
		end


		--[[if not(USBKey)and(PM_drive)then
		   error = "Conecta la llave de PeekMi para continuar\n\bSiperdiste tu llave de PeekMi haz clic en el botón \"Eliminar llave\" luego vuelve a guardar."
		end
		]]--
		--local msg = Dialog.Message("PeekMi", "Si cambias tu contraseña de PeekMi sin tu llave USB conectada, no podrás iniciar sesión con ella y tendrás que configurarla de nuevo.\r\n\r\n¿Deseas cambiar tu contraseña?", MB_YESNO, MB_ICONEXCLAMATION, MB_DEFBUTTON1)
		if not error then
			if PASSCFG then
				DialogEx.StopTimer(1);DialogEx.StopTimer(2);
				Image.SetVisible("cerrar", false);
				CheckBox.SetVisible("updates_chk", false);
				xButton.SetEnabled(this, false);
				local tDatos, num = {}, 0;
		   
		   		PM_DATOS 	  = database:list(PMDAT)
				PM_CATEGORIAS = database:list(PMCAT)
		   		
		   		if PM_DATOS then
			   		n = 1
					while PM_DATOS[n] do
				  			recordid		= PM_DATOS[n].recordid
				  			etiqueta		= PM_DATOS[n].etiqueta
				  			sitioweb		= PM_DATOS[n].sitioweb 				--sitioweb   = crypto(sitioweb  , sContrasena, ENCODE)
				  			usuario 		= crypto(PM_DATOS[n].usuario   , PM_pass, DECODE)				usuario    = crypto(usuario	, sContrasena, ENCODE)
				  			contrasena	= crypto(PM_DATOS[n].password  , PM_pass, DECODE)				contrasena = crypto(contrasena, sContrasena, ENCODE)
				  			comentario  = crypto(PM_DATOS[n].comentario, PM_pass, DECODE)				comentario = crypto(comentario, sContrasena, ENCODE)
							categoria   = PM_DATOS[n].categoria
							
							if not tonumber(categoria) then
								categoria = 0
							end

				  			database:update(PMDAT, {etiqueta, sitioweb, usuario, contrasena, comentario, categoria}, recordid)
				  			--PM.Progreso("progress", 281, 220, n * 100 / #PM_DATOS, tostring(#PM_DATOS).."")
				  			
				  			PM.Progreso("progress", (n / #PM_DATOS) * 100, tLang.SETTINGS.Modificando)
				  			
				  		n = n + 1
					end
				end
				PM_pass = sContrasena
			end
				if USBCFG then
				-- Si seleccionó algun dispositivo USB
					if File.DoesExist(sDispositivoRuta..sFileUSB) then
					-- Si ya existe el archivo de configuracion usb. Eliminamos los archivos anteriores y luego el directorio (EN ESE ORDEN)
						os.remove(sDispositivoRuta..sFileUSB)
						Folder.DeleteTree(sDispositivoRuta..String.SplitPath(sFileUSB).Folder)
					end
					Folder.Create(sDispositivoRuta..String.SplitPath(sFileUSB).Folder)
					TextFile.WriteFromString(sDispositivoRuta..sFileUSB, 'DCano_PM7'..crypto(PM_pass, sDispositivoSerial, ENCODE), false)
				-- Usamos el CommandLine de windows para establecer los atributos de oculto a la carpeta y los archivos necesarios en el dispositivo
					File.Run("cmd.exe", '/k "attrib +h +s .peekmi & attrib +h .peekmi\\pm_cfg & exit"', sDispositivoRuta, SW_HIDE)
				
					PM_SYSTEM = database:list(PMKEY)
					-- Verificamos si existe la entrada de dispositivo usb en la base de datos
					if not PM_SYSTEM[2] then
						database:insert(PMKEY, {Crypto.MD5DigestFromString(crypto(sDispositivoSerial, sDispositivoSerial, ENCODE))})
					else
						database:insert(PMKEY, {Crypto.MD5DigestFromString(crypto(sDispositivoSerial, sDispositivoSerial, ENCODE))})
					end
					PM_drive = database:list(PMKEY)[2].key
				else
					PM_drive = nil
				end

		database:update(PMKEY, {Crypto.MD5DigestFromString(crypto(PM_pass, PM_pass, ENCODE))}, 1)
		CheckBox.SetVisible("updates_chk", true);
		DialogEx.StartTimer(12, 1);DialogEx.StartTimer(12, 2);
		xButton.SetEnabled(this, true)
		settings_cerrar.OnClick("cerrar")
		else
		-- Si hubo algún error
			Mensaje(error, errormsg, errortyp)
		end 
	end,
}

settings_cerrar = {
	OnClick = function (this)
		Image.Load(this, "data\\gui\\close.png")
		Paragraph.SetVisible("info_dispositivo" , false)
		Image.SetVisible(this, true)
		Image.SetVisible("info_dispositivo_i"	, false)
		ListBoxEx.SetVisible("dispositivos_list", false)
		Paragraph.SetVisible("dispositivos_box", false)
		Hotspot.SetEnabled("dispositivos_hot", false)
		PM.BorrarInputs()
		--Image.Load(this, "data\\skin\\close.png")

		Paragraph.SetVisible("quitar_info_pg", false)
		xButton.SetVisible("quitar", false)

		Image.SetVisible("on_input", false)
		Image.SetVisible("info_password_i", false)
		Image.SetVisible("contrasena3_inp_img", false)
		Input.SetVisible("contrasena3_inp", false)
		Paragraph.SetVisible("contrasena3_pg", false)
		Image.SetPos("progress2", 27, 281)
		Image.SetSize("progress1", 5, 12)
		xButton.SetEnabled("guardar_btn", false)

		DialogEx.Close()
	end
}