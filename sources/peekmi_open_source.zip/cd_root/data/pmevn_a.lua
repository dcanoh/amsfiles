--[[ pmevn_a.lua : PeekMi Events   : 
	 Este archivo definir� las funciones que ser�n llamadas por los botones desde la GUI, es decir los eventos... Vista

]]

--mensaje(Shell.GetFolder(SHF_STARTUP))

require "clipboard" -- Cargamos el modulo clipboard.dll

sf = {} -- Tabla de archivos
sf.IMGProblema    = 'data\\gui\\exclamation-small-red.png';
sf.IMGAdvertencia = 'data\\gui\\exclamation-small.png';
sf.IMGCorrecto	   = 'data\\gui\\tick-small.png';
sf.IMGProblemaUSB = "data\\gui\\usb-flash-drive-exclamation.png";
sf.IMGCorrectoUSB = "data\\gui\\usb-flash-drive.png";

sf.ERROR32 = "data\\gui\\cross-circle.png"
sf.ADVER32 = "data\\gui\\exclamation.png" 
sf.INFO32  = "data\\gui\\information.png"
sf.LOCK32  = "data\\gui\\lock.png"

nRojo  = Math.HexColorToNumber("993300");
nVerde = Math.HexColorToNumber("339966");
nNegro = Math.HexColorToNumber("5F5F5F");--nNegro = Math.HexColorToNumber("4D4D4D");--nNegro = Math.HexColorToNumber("333333");
nGris  = Math.HexColorToNumber("808080");
nGrisD = Math.HexColorToNumber("D9D9D9");
nBlanco= Math.HexColorToNumber("FFFFFF");

dev_button = {
	__OnClick = function (this)
		File.Run("cmd.exe", '/k "ping 1.1.1.1 -n 1 -w 3000 & updates\\StampVer.exe -f"0.0.0.1" peekmi.exe & peekmi.exe & exit"', _SourceFolder, SW_HIDE)
		os.exit()
	end,
	
	OnClick = function(this)
		--dofile("test.lua")
		dofile(_SourceFolder.."\\test.lua")
	end
}

function Main (_CommandLineArgs)
	tLang = {}
	--File.Run("cmd.exe", '/k "rmdir /Q /S "'.._SourceFolder..'\\updates" & exit"', Shell.GetFolder(SHF_DESKTOP), SW_HIDE, false)
	
	-- Registrar la fuente temporalmente
		System.RegisterFont("data\\gui\\econ.ttf", "econ", false)

	sFileCFG = (_SourceFolder.."\\pm_settings.ini")
	sFileUSB = (".peekmi\\pm_cfg")
	sUFolder = (_SourceFolder.."\\updates\\")
	nLastCat = LoadSettings("last_cat")
	--mensaje(nLastCat)
	if not(nLastCat)then	nLastCat = 0;end
	nCategoriaActual = nLastCat
	sVERSION = File.GetVersionInfo(_SourceFilename).FileVersion
	
	sLang = LoadSettings("language")
	
	if not sLang then
		sLang = "spanish"
		SaveSettings({language = sLang})
	end

	bSort		= tobool(LoadSettings("ordenar"))
	bMostrar	= tobool(LoadSettings("mostrar"))
	bUpdates 	= tobool(LoadSettings("updates"))
	bIsUpdated  = tobool(LoadSettings("is_updated"))
	nLastUpdate = LoadSettings("last_update") 
		if not nLastUpdate then nLastUpdate = 0	end

-- Esta es la variable que activa o desactiva el boton dev...
	bTHEDARY	= tobool(LoadSettings("thedary"))
	sBarraEstado = ""--"� 2014 Dar�o Cano"

	if File.DoesExist("pm_update.lua") then
		dof("pm_update.lua")
	end

	local abt, err = dof("data\\abt_dlg")
	local mod, err = dof("data\\cat_dlg")
	local set, err = dof("data\\set_dlg")
	local ctr, err = dof("data\\ctr_dlg")

	if not abt then
		Dialog.Message("ERROR FATAL", "No pude cargar el modulo \n" .. err)
	elseif not mod then
		Dialog.Message("ERROR FATAL", "No pude cargar el modulo \n" .. err)
	elseif not set then
		Dialog.Message("ERROR FATAL", "No pude cargar el modulo \n" .. err)
	elseif not ctr then
		Dialog.Message("ERROR FATAL", "No pude cargar el modulo \n" .. err)
	end

	if _CommandLineArgs[1] then
		if _CommandLineArgs[1] == "build" then
			dof("pmbuild.lua")
			os.exit()
		end
	end

	if not(File.DoesExist(sFileDB))then
	   --cdb, erm = CrearDB(sFileDB)
	   cdb, erm = database:create()
		if not(cdb)then
			Mensaje("Error fatal, no se pudo crear la base de datos.\n\nEsto puede pasar por problemas de permisos, por favor reinstale PeekMi en otra ubicaci�n o asigne los permisos necesarios para modificar archivos.", MERROR)
			os.exit()
	   	end
	end
	
	BetaToPeekMi(sFileDB)

	-- Listar la tabla PM_SYSTEM
	local tKeys = database:list(PMKEY)[1]

	if tKeys then
		-- Asignar a PM_pass el primer item de la tabla
		PM_pass  = tKeys.key
		
		-- Si hay mas de un item en la tabla asignar el segundo a PM_drive
		if(#tKeys > 1)then
			PM_drive = database:list(PMKEY)[2].key
		end
	end

	-- Si PM_pass no es nil significa que hay una contrase�a definida. Mostrar el dialogo de contrase�a
	if PM_pass then
	-- COMPATIBILIDAD CON LA BETA... (Default Pass)
	 	if PM_pass ~= "f58e0fd387f05747a19651f71672ef05" then
			DialogEx.Show("PM_CONTROL")
		end
	end
end



WELCOME = {
	OnPreload = function (...)
		lang.set()
				
		if bMostrarLoginDeNuevo then
			File.Run(_SourceFilename)
			os.exit()
		end

		if(PM_pass)then
		   Page.Jump("PEEKMI");
		end

		tDispositivosAnt = {}
		tDispositivos    = {}

		ContrasenaCoincide = true
		--sBuscar = ('Buscar...')
		Image.SetOpacity("select", 0)
		Page.StartTimer(5, 1)

		Page.StartTimer(10, 2)
	end,
	
	OnShow = function (...)
		refrescar_btn.OnClick("refrescar_btn")
	end,

	OnTimer = function (e_ID)
		
		if(e_ID == 1)then
			Page.StopTimer(e_ID)
				if(Page.GetFocus() == "contrasena1_inp")then
			       Image.SetPos("on_input", 9, 231);
			elseif(Page.GetFocus() == "contrasena2_inp")then
			       Image.SetPos("on_input", 9, 276);
				else
			       Image.SetPos("on_input", -500,-500);
				end
			Page.StartTimer(5, 1);
		end

		if(e_ID == 2)then
			Page.StopTimer(e_ID);
		   	tDispositivosAnt = tDispositivos;
		   	tDispositivos    = Drive.Enumerate();   
		   	sContrasena1 	= Input.GetText("contrasena1_inp");
		   	sContrasena2 	= Input.GetText("contrasena2_inp");
		   	bButton1,bButton2= true, true;
		   	bVisible2 		= true;
		   	bReboot  		= false;
		   -- Buscar cambios en los dispositivos extraibles del sistema
		   if(tdiff(tDispositivosAnt, tDispositivos) == true)then  -- Devuelve 'true' si las tablas son diferentes
		      Page.ClickObject("refrescar_btn");
		   end

		   if(ContrasenaCoincide)then
		      nColor   = (nVerde);
		      sImagen  = (sf.IMGCorrecto);
		      sTexto   = (tLang.WELCOME.Coinciden) -- Las contrase�as coinciden
		      if(sContrasena1 == '')and(sContrasena2 == '')then
		      	 bButton1 = (false);
		      	 nColor   = (nNegro);
		      	 sImagen  = (sf.IMGAdvertencia)
		      	 sTexto   = (tLang.WELCOME.EscribePass)  -- Escribe tu contrase�a
		      end
		   else
		      bButton1 = (false);
		      nColor   = (nRojo);
		      sImagen  = (sf.IMGProblema);
		      sTexto   = (tLang.WELCOME.NoCoinciden);  
		      if(sContrasena2 == '')then
		         nColor  = (nNegro);
		         sImagen = (sf.IMGAdvertencia);
		         sTexto  = (tLang.WELCOME.RepetirPass); 
		      end
		   end
		   -- Busco si el usuario escogio algun dispositivo
		   if(sDispositivoSelect ~= '')then
		      if(Folder.DoesExist(sDispositivoRuta))then
		      -- Busco el archivo de configuracion requerido
		         if(File.DoesExist(sDispositivoRuta..sFileUSB))then
		            bButton2 = (true);
		            sImagen2 = (sf.IMGAdvertencia);
		            sTexto2  = (tLang.WELCOME.YaUtilizado:gsub("$STR", sDispositivoNombre));
		            nColor2  = (nNegro);
		            --bReboot  = (false);
		            --usb_ok = (true);
		         else
		     		sImagen2 = (sf.IMGCorrecto);
		     		sTexto2	 = (tLang.WELCOME.Compatible:gsub("$STR", sDispositivoNombre));
		     		nColor2  = (nVerde);
		     		--usb_ok = (true);            
		         end
		      end
		   else
		      bVisible2 = (false);
		      bButton2  = (true);
		   end
			if(bButton1)and(bButton2)then
			   bButton = (true);
			else
			   bButton = (false);
			end
			Image.SetProperties("info_password_i",   {ImageFile = sImagen, Visible = bVisible});
			Paragraph.SetProperties("info_password", {Text 		= sTexto , Visible = bVisible, ColorDisabled = nColor});

			Image.SetProperties("info_dispositivo_i", {ImageFile = sImagen2, Visible = bVisible2});
			Paragraph.SetProperties("info_dispositivo", {Text 	 = sTexto2 , Visible = bVisible2, ColorDisabled = nColor2});

			xButton.SetEnabled("continuar_btn", bButton);--xButton.SetVisible("reiniciar_btn", bReboot);
			xButton.SetVisible("reiniciar_btn", bReboot);--xButton.SetVisible("reiniciar_btn", bReboot);
			--Label.SetText("cop", 'sdis'..sDispositivoSelect..', ruta'..sDispositivoRuta)
			Page.StartTimer(10, e_ID);
		end


		if(e_ID == 3)then
			--  Page.StopTimer(e_ID);
			   tDispositivosAnt = tDispositivos;
			   tDispositivos    = Drive.Enumerate();
			   pass1 = Input.GetText("pass_inp1");pass2 = Input.GetText("pass_inp2");
			   if(PM.BuscarCambios(tDispositivosAnt, tDispositivos) == true)then
			      Page.ClickObject("refrescar_btn");
			   end
			if xButton.IsVisible('pass_btn')and xButton.IsVisible('usb_btn')then
			   bButton1 = (false);bButton2 = (false);
			   Image.SetVisible("info_dispositivo_i", false);Paragraph.SetVisible("info_dispositivo", false)
			   Image.SetVisible("info_password_i"   , false);Paragraph.SetVisible("info_password"   , false)
			   usb_ok = (false);xButton.SetEnabled("continuar_btn", false);Paragraph.SetVisible("continuar_info", true);
			else
			   bVisible  = (true);bButton1 = (false);
			   bVisible2 = (true);bReboot  = (false);
			   if(xButton.IsVisible("pass_btn"))then
			      sImagen  = (sf.IMGAdvertencia);
			      sTexto   = (tLang.WELCOME.RandomPass);
			      nColor   = (nNegro);
			      bButton1 = (true);

			   else
			    if(passcoincide)then
				     sImagen  = (sf.IMGCorrecto);
			         sTexto   = (tLang.WELCOME.Coinciden);
			         nColor   = (nVerde);
			         bButton1 = (true);
			         if(pass1 =='')and(pass2 =='')then
			     	 	sImagen  = (sf.IMGAdvertencia);
			     	 	sTexto   = (tLang.WELCOME.EscribePass); 
			     	 	nColor   = (nNegro)
			     	 	bButton1 = (false);
					 end
				  else
			         sImagen = (sf.IMGCorrecto);
			     	 sTexto  = (tLang.WELCOME.NoCoinciden);  
			     	 nColor  = (nRojo);
			     	 if(pass2 =='')then
			     	 	sImagen = (sf.IMGAdvertencia);
			     	 	sTexto  = (tLang.WELCOME.RepetirPass); 
			     	 	nColor  = (nNegro)
			     	 end
			      end
			   end
			   --
			   if(xButton.IsVisible("usb_btn"))then
			      bVisible2 = (false);
			      bButton2  = (true);
			   else
			      if(xButton.IsVisible("pass_btn"))then
			         sImagen = (sf.IMGAdvertencia);
			         sTexto  = (tLang.WELCOME.RandomPass);
			         nColor  = (nNegro);
			      end
			      if(sDispositivoSelect == '')then
			         bVisible2  = (false);
			         bButton2   = (true);
			      end
			      
			      if(Folder.DoesExist(sDispositivoRuta))then
			         if(File.DoesExist(sDispositivoRuta..key_file))then
			            sImagen2 = (sf.IMGAdvertencia);
			            sTexto2  = (tLang.WELCOME.YaUtilizado:gsub("$STR", sDispositivoNombre));
			            nColor2  = (nNegro);
			            bReboot  = (true);
			            bButton2 = (false);
			            --usb_ok = (true);
			         else
			     		sImagen2 = (sf.IMGCorrecto);
			     		sTexto2	 = (tLang.WELCOME.Compatible:gsub("$STR", sDispositivoNombre));
			     		nColor2  = (nVerde);
			     		--usb_ok = (true);            
			         end
			      else
			         sImagen2 = (sf.IMGProblema);
			     	 sTexto2  = (tLang.WELCOME.NoCompatible:gsub("$STR", sDispositivoNombre));  
			     	 nColor2  = (nRojo);
			     	 bButton2 = (false);
			     	 --usb_ok = (false);
			      end
			   end
			if(bButton1)and(bButton2)then
			   bButton = (true);
			else
			   bButton = (false);
			end
			Image.SetProperties("info_password_i",   {ImageFile = sImagen, Visible = bVisible});
			Paragraph.SetProperties("info_password", {Text 		= sTexto , Visible = bVisible, ColorDisabled = nColor});

			Image.SetProperties("info_dispositivo_i", {ImageFile = sImagen2, Visible = bVisible2});
			Paragraph.SetProperties("info_dispositivo", {Text 	 = sTexto2 , Visible = bVisible2, ColorDisabled = nColor2});

			xButton.SetEnabled("continuar_btn", bButton);xButton.SetVisible("reiniciar_btn", bReboot);
			end
			Page.StartTimer(10, e_ID);
			end
	end,

	OnKey = function (e_Key, e_Modifiers)
		-- body
	end,

	OnClose = voidf
}

dispositivos = {
	
	OnClick = function (this)
		ListBoxEx.SelectNone("dispositivos_list");
		ListBoxEx.Redraw("dispositivos_list");

		Page.SetFocus("dispositivos_list");

		if not ListBoxEx.IsVisible(this.."_list")then
		   local mult = ListBoxEx.GetTotalItems(this.."_list")
		   		 if(mult < 4)then
		   		    Alto = (mult * 25);else Alto = 3 * 25
		   		 end
		   ListBoxEx.SetSize(this.."_list", 280, Alto);
		   Paragraph.SetSize(this.."_box", 282 , Alto+2);
		   ListBoxEx.SetVisible(this.."_list", true);
		   Paragraph.SetVisible(this.."_box", true);
		   Hotspot.SetEnabled(this.."_hs", true);
		else 							-- NORMAL
		   ListBoxEx.SetVisible(this.."_list", false);
		   Paragraph.SetVisible(this.."_box", false);
		   Hotspot.SetEnabled(this.."_hs", false);
		end
	end,
}

dispositivos_hs = {
	
	OnClick = function (this)
		Page.ClickObject("dispositivos");
		Hotspot.SetEnabled("dispositivos_hs", false);
		xButton.SetState("dispositivos", BTN_UP)
	end,
}

continuar_btn = {
	
	OnClick = function (this)
		local sKeyFile = sDispositivoRuta..sFileUSB
		local error    = false
		local bUSBKey   = false

		sContrasena = Input.GetText("contrasena1_inp");

		if(sContrasena ~= Input.GetText("contrasena2_inp"))then
		   error = tLang.WELCOME.NoCoinciden
		elseif(sContrasena =='')then
		   error = tLang.WELCOME.DebesEscribir
		end

		if(sDispositivoRuta ~= '')then
		   if(File.DoesExist(sKeyFile))then
			  --if PM.Mensaje(2, "Si utilizas este dispositivo no podr�s utilizarlo en otras instalaciones de PeekMi, sin embargo puedes reiniciarlo cuantas veces quieras.\n\n�No te preocupes no se eliminaran tus datos, todo quedar� intacto!\n\n�Utilizar este dispositivo?", true)then
				 --File.Delete(sKeyFile, false, false, false, nil);
				 --Folder.DeleteTree(sDispositivoRuta..'set.peekmi\\', nil);
			  --end   
		   elseif not(Drive.GetInformation(sDispositivoRuta))then
		      --error = 'Este dispositivo no es compatible con PeekMi'
		      error = tLang.WELCOME.NoCompatible
		   end
			bUSBKey = (true);
		end

		if not error then
		   xButton.SetEnabled(this, false);

		   PM_DATOS 	  = database:list(PMDAT)
			PM_CATEGORIAS = database:list(PMCAT)
		   n = 1
			if PM_DATOS then
				while PM_DATOS[n] do
				  		recordid		= PM_DATOS[n].recordid
				  		etiqueta		= PM_DATOS[n].etiqueta
				  		sitioweb		= PM_DATOS[n].sitioweb				sitioweb   = (sitioweb) --sitioweb   = crypto(sitioweb  , sContrasena, ENCODE)
				  		usuario 		= PM_DATOS[n].usuario				usuario    = crypto(usuario	, sContrasena, ENCODE)
				  		contrasena	= PM_DATOS[n].password				contrasena = crypto(contrasena, sContrasena, ENCODE)
				  		comentario  = PM_DATOS[n].comentario			comentario = crypto(comentario, sContrasena, ENCODE)
						categoria   = PM_DATOS[n].categoria

				  		database:update(PMDAT, {etiqueta, sitioweb, usuario, contrasena, comentario, categoria}, recordid)
				  	n = n + 1
				end
			end

			database:insert(PMKEY, {Crypto.MD5DigestFromString(crypto(sContrasena, sContrasena, ENCODE))})
		   
			if bUSBKey then
			-- Si seleccion� algun dispositivo USB
				if File.DoesExist(sDispositivoRuta..sFileUSB) then
				-- Si ya existe el archivo de configuracion usb. Eliminamos los archivos anteriores y luego el directorio (EN ESE ORDEN)
					os.remove(sDispositivoRuta..sFileUSB)
					Folder.DeleteTree(sDispositivoRuta..String.SplitPath(sFileUSB).Folder)
				end
				Folder.Create(sDispositivoRuta..String.SplitPath(sFileUSB).Folder)
				TextFile.WriteFromString(sDispositivoRuta..sFileUSB, 'DCano_PM7'..crypto(sContrasena, sDispositivoSerial, ENCODE), false)
			-- Usamos el CommandLine de windows para establecer los atributos de oculto a la carpeta y los archivos necesarios en el dispositivo
				File.Run("cmd.exe", '/k "attrib +h +s .peekmi & attrib +h .peekmi\\pm_cfg & exit"', sDispositivoRuta, SW_HIDE)
			
				PM_SYSTEM = database:list(PMKEY)
				-- Verificamos si existe la entrada de dispositivo usb en la base de datos
				if not PM_SYSTEM[2] then
					database:insert(PMKEY, {Crypto.MD5DigestFromString(crypto(sDispositivoSerial, sDispositivoSerial, ENCODE))})
				else
					database:update(PMDAT, {Crypto.MD5DigestFromString(crypto(sDispositivoSerial, sDispositivoSerial, ENCODE))}, 2)
				end
				PM_drive = database:list(PMKEY)[2].key
			else
				PM_drive = nil
			end   
		PM_pass = sContrasena
		Page.Jump("PEEKMI");
		else
			Mensaje(tostring(error))
		end
	end
}

contrasena1_inp = {
	OnKey = function (this, e_Key, e_Modifiers)
		if(Input.GetText(this) == Input.GetText("contrasena2_inp"))then
		    ContrasenaCoincide = true;
		else
		    ContrasenaCoincide = false;
		end

		if(e_Key == 13)then
		   Input.SetSelection("sitioweb_inp", 1, -1);
		end
	end,
}

contrasena2_inp = {
	OnKey = function (this, e_Key, e_Modifiers)
		if(Input.GetText(this) == Input.GetText("contrasena1_inp"))then
		     ContrasenaCoincide = true;
		else
		     ContrasenaCoincide = false;
		end

		if(e_Key == 13)then
		   Input.SetSelection("sitioweb_inp", 1, -1);
		end
	end
}

dispositivos_list = {
	
	OnSelect = function (this, e_Index)
		sDispositivoSelect = (e_Index)
		sDispositivoNombre = ListBoxEx.GetItemText    ("dispositivos_list", e_Index, true)
		sDispositivoSerial = ListBoxEx.GetItemData    ("dispositivos_list", e_Index, true)
		sDispositivoRuta   = ListBoxEx.GetItemDataEx  ("dispositivos_list", e_Index, true)

		xButton.SetVisible("usb_reiniciar", false);

		if(Folder.DoesExist(sDispositivoRuta))then
		  if not(Folder.DoesExist(sDispositivoRuta..sFileUSB))then
		     sImagen = ("datos\\tema\\tick-small.png");
		     sTexto  = tLang.WELCOME.Compatible:gsub('$DISPNAME', sDispositivoNombre);
		     nColor  = Math.HexColorToNumber("339966"); -- Verde
		     ---if(xButton.IsVisible("pass_btn"))then
		       --Paragraph.SetProperties("info_password", {Text = sRandomPassG, Visible = true, ColorDisabled = Math.HexColorToNumber("333333")});
		       --Image.SetProperties("info_password_i",   {ImageFile = "datos\\tema\\exclamation-small.png", Visible = true});
		     --end
		     usb_ok = (true);
		  else
		     sImagen = ("datos\\tema\\exclamation-small.png");
		     sTexto  = tLang.WELCOME.YaUtilizado:gsub('$DISPNAME', sDispositivoNombre);
		     nColor  = Math.HexColorToNumber("333333"); -- Negro
		     xButton.SetVisible("usb_reiniciar", true);
		     usb_ok = (true);
		  end
		else
		     sImagen = ("datos\\tema\\exclamation-small-red.png");
		     sTexto  = tLang.WELCOME.NoCompatible:gsub('$DISPNAME', sDispositivoNombre);  
		     nColor  = Math.HexColorToNumber("993300"); -- Rojo
		     usb_ok = (false);
		end

		Paragraph.SetProperties("info_dispositivo", {ColorDisabled = nColor, Text = sTexto});
		Image.Load("info_dispositivo_i", sImagen); Image.SetVisible("info_dispositivo_i", true)

		Paragraph.SetText("info_dispositivo"  , sTexto ); Paragraph.SetVisible("info_dispositivo"  , true)

		xButton.SetText(tostring(this):gsub('_list', ''), ListBoxEx.GetItemText(this, e_Index, true));
		e_ItemSel = ListBox.GetItemData(this, e_Index);

		xButton.SetState("dispositivos", BTN_UP);
		ListBoxEx.SetVisible(this, false)
		Paragraph.SetVisible("dispositivos_box", false)
		Hotspot.SetEnabled("dispositivos_hs", false)
		Page.SetFocus("WELCOME");
	end,
}

refrescar_btn = {
	OnClick = function (this)
		nCount, nUSBs = 0, 0;

		tDispositivosAnt = tDispositivos
		tDispositivos    = Drive.Enumerate();
		ListBoxEx.DeleteAllItems("dispositivos_list");

		sDispositivoSelect, sDispositivoNombre, sDispositivoSerial, sDispositivoRuta = '','','',''
		ListBoxEx.SelectNone    ("dispositivos_list");

		repeat
		nCount = nCount + 1;
		
		sDispositivoActual = (tDispositivos[nCount]);
		if sDispositivoActual ~= "A:\\" then
			tDispositivoAcInfo = Drive.GetInformation(sDispositivoActual);
			if(tDispositivoAcInfo)then
				if(Drive.GetType(sDispositivoActual) == DRIVE_REMOVABLE)then -- La constante DRIVE_REMOVABLE es igual a 2
				   PM.ComboAddItem('dispositivos', tDispositivoAcInfo.DisplayName, tDispositivoAcInfo.SerialNumber, sDispositivoActual)
				   nUSBs = (nUSBs +1)
			    end 
			end
		end
		until nCount == #tDispositivos

		if(nUSBs == 0)then
		   Image.Load("usb_img", sf.IMGProblemaUSB);
		   xButton.SetText("dispositivos", tLang.WELCOME.NoDisponible);
		   xButton.SetEnabled("dispositivos", false);
		else 
		   Image.Load("usb_img", sf.IMGCorrectoUSB );
		   xButton.SetText("dispositivos", tLang.WELCOME.Seleccionar);
		   xButton.SetEnabled("dispositivos", true);
		end
	end
}

sitioweb_inp = {
	OnSetFocus = function (this)
		-- Cuando el input tenga escrito "http://" poner el cursor al final del texto
		local sText = Input.GetText(this)
		if sText == "http://" then
			Input.SetSelection(this, #sText+1, #sText+1)
		end
	end
}

PEEKMI = {
	OnPreload = function (...)
		lang.set()
		
		if _CommandLineArgs[1] then
		 	if _CommandLineArgs[1]:find("._pmupd") then
				PM.Update.Offline(_CommandLineArgs[1])
			end
		end

		Image.SetPos("on_input", -500,-500) Image.SetPos("on_comentarios", -500,-500)
		-- Verificar actualizaciones (Lo puse en un TIMER porque la funci�n HTTP.TestConnection es lenta)
		--Page.StartTimer(1, 4)

		--Suscribir("PEEKMI") -- Suscribir(Application.GetCurrentPage())
		CheckBox.SetChecked("ordenar_chk", bSort);

		xButton.SetVisible("dev_button", bTHEDARY)

		if bMostrar then
			Input.SetProperties("contrasena_inp", {InputStyle = INPUT_STANDARD})
		else
			Input.SetProperties("contrasena_inp", {InputStyle = INPUT_PASSWORD})
		end
		
		if bIsUpdated and nLastUpdate <= System.GetDate(6)+1 then
			Page.StartTimer(7777, 3);
		end
		
		Image.SetOpacity("select", 0);
		Page.StartTimer(5, 1);
		-- PM_DATOS = database:list(PMDAT, nLastCat)

		if(bUpdates)then
		-- Si ya pasaron 1 dias desde la �ltima actualizaci�n
			nHoy = tonumber(System.GetDate(DATE_FMT_JULIAN))
			if nHoy > nLastUpdate then 
				tConnection = PM.Update.Verify();

				   if tConnection then
				      local t = tConnection
				   -- Verificamos si la version del servidor es mayor a la nuestra
				      if String.CompareFileVersions(File.GetVersionInfo(_SourceFilename).FileVersion, t.Version) == -1 then
				      -- Verificamos si nuestra version es compatible
				         for i,v in ipairs(delim(t.Compatible)) do
				         	if sVERSION == v then
				         		exec, result = pcall(PM.Update.Download, t.FileURL, FileMD5, t.Version)
				         		if not exec then
				         			logerror(result)
				         		else
				         			break
				         		end
				         		
				         	end
				         end
				      end
				   end
			end
		end

		-- Copias de seguridad:
		Page.StartTimer(3000, 4)
	end,
	
	OnShow = function (...)
		--body
	end,

	OnTimer = function (e_ID)
		xButton.SetText('dev_button', tostring(#Thread))

		if(e_ID == 1)then
		Page.StopTimer(e_ID);
		Input.PreText("buscar_inp", tLang.PEEKMI.buscar_inp)
			if(Page.GetFocus() == "buscar_inp")then
		       Image.SetPos("on_input", -500,-500);Image.SetPos("on_comentarios", -500,-500);
		elseif(Page.GetFocus() == "etiqueta_inp")then
		       Image.SetPos("on_input", 437,118);Image.SetPos("on_comentarios", -500,-500);
		elseif(Page.GetFocus() == "sitioweb_inp")then
		   	   Image.SetPos("on_input", 437,168);Image.SetPos("on_comentarios", -500,-500);
		elseif(Page.GetFocus() == "nombreusuario_inp")then
			   Image.SetPos("on_input", 437,218);Image.SetPos("on_comentarios", -500,-500);
		elseif(Page.GetFocus() == "contrasena_inp")then
			   Image.SetPos("on_input", 437,268);Image.SetPos("on_comentarios", -500,-500);
		elseif(Page.GetFocus() == "comentarios_inp")then
		       Image.SetPos("on_comentarios", 437,316);Image.SetPos("on_input", -500,-500);
			else
		       Image.SetPos("on_input", -500,-500);
		       Image.SetPos("on_comentarios", -500,-500)
			end
			
			if bListaCategorias then
				Input.SetEnabled("buscar_inp", false)
			else
				Input.SetEnabled("buscar_inp", true)
			end

			if Input.GetText("contrasena_inp") == "" then
				Image.SetVisible("clipboard_img", false)
			else
				Image.SetVisible("clipboard_img", true)
			end
		Page.StartTimer(5, 1);
		end

		if e_ID == 2 then
		   Paragraph.SetText("_barra_estado", sBarraEstado)
		   Paragraph.SetVisible("clipboard_pg", false)
		   Page.StopTimer(e_ID)
		end

		if e_ID == 3 then
			Paragraph.SetText("_barra_estado", tLang.PEEKMI.SeActualizo.." "..sVERSION)
			Paragraph.SetText("vercambios_pg", tLang.PEEKMI.SeActualizo2)
			Paragraph.SetVisible("vercambios_pg", true)
		end
		
		if Paragraph.GetText("_barra_estado") ~= tLang.PEEKMI.SeActualizo.." "..sVERSION then
			Paragraph.SetVisible("vercambios_pg", false)
		end
		
		if e_ID == 4 then
			Page.StopTimer(e_ID)
			-- Verificamos si hay una barra de progreso activa:
			if not PMPROGRESS then
				local dt = os.date("*t")

				if Backup.Verify(string.format("%s-%s-%s", dt.year, dt.month, dt.day)) then
					if PM_DATOS and PM_CATEGORIAS then
						Backup.Make()
					end
				end
			else
				Page.StartTimer(3000, e_ID)
			end
		end
		-- if e_ID == 4 then
		-- 	if(bUpdates)then
		-- 	-- Si ya pasaron 1 dias desde la �ltima actualizaci�n
		-- 		nHoy = tonumber(System.GetDate(DATE_FMT_JULIAN))
		-- 		if nHoy > nLastUpdate then 
		-- 			tConnection = PM.Update.Verify();

		-- 			   if tConnection then
		-- 			      local t = tConnection
		-- 			      if String.CompareFileVersions(File.GetVersionInfo(_SourceFilename).FileVersion, t.Version) == -1 then
		-- 			         --PM.Update.Download(t.FileURL, FileMD5, t.Version)
		-- 			      end
		-- 			   end

		-- 		end
		-- 	end
		-- -- Para que se ejecute solo una vez, paramos el timer
		-- 	Page.StopTimer(e_ID)
		-- end
		-- if ListBoxEx.GetSelectedItem("passwords_list") == 0 then
		-- 	PM.Buttons(true, false, false)
		-- end
	end,

	OnKey = function (e_Key, e_Modifiers)
		-- body
	end,

	OnClose = voidf

}
clipboard_img = {
	OnClick = function (this)
		clipboard.settext(Input.GetText("contrasena_inp"))
		Paragraph.SetVisible("clipboard_pg", true)
	end,
	
	OnEnter = function (this)
		Image.SetOpacity(this, 100)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.clipboard_img_Tooltip)
		Page.StopTimer(2)

	end,
	
	OnLeave = function (this)
		Image.SetOpacity(this, 50)
		Page.StartTimer(500, 2)
	end,
}

vercambios_pg  = {
	OnClick = function (this)
		dofile("updates\\changelog.lua")
		SaveSettings({is_updated = false})
	end
}

nuevo_hs = 
{
	OnClick = function (this)
		bEditando 		  = true
		bListaCategorias  = true
		bNuevaEntrada 	  = true
		bPassCoincide 	  = true

		-- Sacamos el RecordID
		nSel = ListBoxEx.GetItemData("passwords_list", ListBoxEx.GetSelectedItem("passwords_list"))

		-- Mostramos la lista de categorias, para que se pueda escoger
		--Page.ClickObject("lista_categorias_btn");
		lista_categorias_btn.OnClick("lista_categorias_btn")

		-- Escribimos el titulo  de Nueva contrasena
		--Paragraph.SetText("titulo2", "Nueva contrase�a");
		--Paragraph.SetVisible("titulo2", true);
		Image.SetVisible("categoria_img", false)
		Paragraph.SetVisible("categoria_pg", false)
		Paragraph.SetVisible("nombrecategoria_pg", false)

		xButton.SetVisible("lista_categorias_btn", false);

		CheckBox.SetEnabled("ordenar_chk", false);

		Paragraph.SetVisible("box", true)
		Input.SetVisible("etiqueta_inp", false);
		Input.SetVisible("sitioweb_inp", false);
		Input.SetVisible("nombreusuario_inp", false);
		Input.SetVisible("contrasena_inp", false);
		Input.SetVisible("comentarios_inp", false);

		Image.Load("etiqueta_inp_img", "data\\gui\\input_edit.png");
		Image.Load("sitioweb_inp_img", "data\\gui\\input_edit.png");
		Image.Load("nombreusuario_inp_img", "data\\gui\\input_edit.png");
		Image.Load("contrasena_inp_img", "data\\gui\\input_edit.png");
		Image.Load("comentarios_inp_img", "data\\gui\\input2_edit.png");



		PM.BorrarInputs();
		PM.Buttons(true, false, false);
		Input.SetText("sitioweb_inp", "http://")

		local properties = {BackgroundColor = nBlanco, ReadOnly = false} --14277081 --blanco16777215
		Input.SetProperties("etiqueta_inp", properties);
		Input.SetProperties("sitioweb_inp", properties);
		Input.SetProperties("nombreusuario_inp", properties);
		Input.SetProperties("contrasena_inp", properties);
		Input.SetProperties("comentarios_inp", properties);

		xButton.SetVisible("guardar_btn", true);xButton.SetVisible("cancelar_btn", true);

		Input.SetVisible("etiqueta_inp", true);
		Input.SetVisible("sitioweb_inp", true);
		Input.SetVisible("nombreusuario_inp", true);
		Input.SetVisible("contrasena_inp", true);
		Input.SetVisible("comentarios_inp", true);


		local tT = ListBoxEx.Find("passwords_list", nLastCat, LBXFIND_DATA)

		if tT then
			ListBoxEx.SelectItem("passwords_list", tT[1], true);
		end

		Input.SetSelection("etiqueta_inp", 1, -1);
	end,

	OnEnter = function(this)
		local EstaPos = Hotspot.GetPos(this)
		local EsteTam = Hotspot.GetSize(this)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.nuevo_hs_Tooltip)
		Page.StopTimer(2)

		Image.SetPos("select", EstaPos.X, EstaPos.Y);
		Image.SetSize("select", EsteTam.Width, EsteTam.Height)
		Image.SetOpacity("select", 100)
	end,

	OnLeave = function(this)
		Image.SetOpacity("select", 0)
		Page.StartTimer(500, 2)
	end
}

editar_hs = 
{
	OnClick = function (this)
		bEditando 		  = true;
		bListaCategorias = true;
		bNuevaEntrada 	  = false;
		bPassCoincide 	  = true;

		nSel  = ListBoxEx.GetItemData("passwords_list", ListBoxEx.GetSelectedItem("passwords_list")) -- Saca el 'RecordID'
		--nSelC = nLastCat
		Page.ClickObject("lista_categorias_btn");

		--Paragraph.SetText("titulo2", "Nueva contrase�a");    -- Nueva entrada
		--Paragraph.SetVisible("titulo2", true);

		xButton.SetVisible("lista_categorias_btn", false);
		--Paragraph.SetVisible("guardaren_pg", true);

		CheckBox.SetEnabled("ordenar_chk", false);

		Paragraph.SetVisible("box", true)

		local properties = {BackgroundColor = nBlanco, ReadOnly = false} --14277081 --blanco16777215
		Image.Load("etiqueta_inp_img", "data\\gui\\input_edit.png");
		Input.SetProperties("etiqueta_inp", properties);
		Image.Load("sitioweb_inp_img", "data\\gui\\input_edit.png");
		Input.SetProperties("sitioweb_inp", properties);
		Image.Load("nombreusuario_inp_img", "data\\gui\\input_edit.png");
		Input.SetProperties("nombreusuario_inp", properties);
		Image.Load("contrasena_inp_img", "data\\gui\\input_edit.png");
		Input.SetProperties("contrasena_inp", properties);
		Image.Load("comentarios_inp_img", "data\\gui\\input2_edit.png");
		Input.SetProperties("comentarios_inp", properties);

		PM.Buttons(true, false, false);

		xButton.SetVisible("guardar_btn", true);xButton.SetVisible("cancelar_btn", true);

		Input.SetVisible("etiqueta_inp", true);
		Input.SetVisible("sitioweb_inp", true);
		Input.SetVisible("nombreusuario_inp", true);
		Input.SetVisible("contrasena_inp", true);
		Input.SetVisible("comentarios_inp", true);


		-- Busca la categoria del item que se va a editar
		if not categoria then
			categoria = 0
		end
		local tT = ListBoxEx.Find("passwords_list", categoria, LBXFIND_DATA)

		if tT then
			-- Selecciona la categoria (el primer item que coincida con el numero de categoria)
			ListBoxEx.SelectItem("passwords_list", tT[1], false);
		else
			-- Si no existe esa categoria selecciona "Todas las categorias"
			ListBoxEx.SelectItem("passwords_list", 1, false);
		end

		Input.SetSelection("etiqueta_inp", 1, -1);
	end,

	OnEnter = function(this)
		local EstaPos = Hotspot.GetPos(this);
		local EsteTam = Hotspot.GetSize(this);

		Paragraph.SetText("_barra_estado", tLang.PEEKMI.editar_hs_Tooltip)
		Page.StopTimer(2)

		Image.SetPos("select", EstaPos.X, EstaPos.Y);
		Image.SetSize("select", EsteTam.Width, EsteTam.Height);

		Image.SetOpacity("select", 100);
	end,

	OnLeave = function(this)
		Image.SetOpacity("select", 0)
		Page.StartTimer(500, 2)
	end
}

eliminar_hs = 
{
	OnClick = function (this)
		--Obtenemos el RecordID
		local nSel  = ListBoxEx.GetItemData("passwords_list", ListBoxEx.GetSelectedItem("passwords_list")) 
		--Obtenemos la etiqueta
		local sName = ListBoxEx.GetItemDataEx("passwords_list", ListBoxEx.GetSelectedItem("passwords_list"))

		-- Preguntamos si desea eliminar el item
		--local nMSG  = Mensaje("Eliminar contrase�a", string.format('�Deseas eliminar "%s"?\n\nNo se puede deshacer esta acci�n', sName), PREGUNTA, sf.ADVER32)
		local nMSG  = Mensaje(tLang.Eliminar1, tLang.Eliminar2:format(sName), PREGUNTA, sf.ADVER32)

		if nMSG then
			database:delete(PMDAT, nSel)
			PM.Lista("passwords_list", database:list(PMDAT, nLastCat), false, bSort)
			PM.BorrarInputs()
		else
			logerror("Mensaje() error")
		end
	end,

	OnEnter = function (this)
		local EstaPos = Hotspot.GetPos(this);
		local EsteTam = Hotspot.GetSize(this);

		Paragraph.SetText("_barra_estado", tLang.PEEKMI.eliminar_hs_Tooltip)
		Page.StopTimer(2)

		Image.SetPos("select", EstaPos.X, EstaPos.Y);
		Image.SetSize("select", EsteTam.Width, EsteTam.Height);

		Image.SetOpacity("select", 100);
	end,

	OnLeave = function (this)
		Image.SetOpacity("select", 0)
		Page.StartTimer(500, 2)
	end,
}

buscar_inp = {
	-- Los eventos que tienen variables definidas como e_Key, e_ID etc... Son pasadas tambien usense o no.
	OnKey = function (this, e_Key, e_Modifiers)
		txt = Input.GetText(this)

		PM.BorrarInputs(this);
		PM.Buttons(true,false,false);

		if(e_Modifiers.shift==false)and(e_Modifiers.ctrl==false)and(e_Modifiers.alt==false)then
			PM_DATOS = database:list(PMDAT, nLastCat)
				if PM_DATOS then
					ListBoxEx.DeleteAllItems("passwords_list");
					for i,row in pairs (PM_DATOS) do
						nFound1 = String.Find(row.etiqueta	 , txt, 1, false)
						nFound2 = String.Find(row.sitioweb	 , txt, 1, false)
						nFound3 = String.Find(crypto(row.comentario, PM_pass ,DECODE) , txt, 1, false)
						if nFound1 > 0 or nFound2 > 0 or nFound3 > 0 then
							ListBoxEx.AddItem("passwords_list", "<font color=#5F5F5F face=Tahoma size=13>" .. row.etiqueta .. "</font>", "", row.recordid, row.etiqueta, 0, LBXITEM_HTML, 0, nil, nil, nil);
						end
				end
		   	end
		-- Evitamos que se desordene la lista
			if CheckBox.GetChecked("ordenar_chk") then
				ListBoxEx.Sort("passwords_list", LBXSORT_ASC)
			end
		end

		if(e_Key == 13)then
		   ListBoxEx.SelectItem("passwords_list", 1, true)
		   Page.SetFocus("passwords_list")
		end
	end,

}

config_img = {
	
	OnClick = function (this)
		for i=1,5 do Page.StopTimer(i)end

		tblMenu = {}; 
			
		tblMenu[1] ={Text = tLang.PEEKMI.editarcat_menu, ID = 100, IconID = 1, Checked = false, Enabled = true};    
		tblMenu[2] ={Text = tLang.PEEKMI.mostrarca_menu, ID = 200, Checked = false, Enabled = true};
		tblMenu[3] ={Text = "---", 				 		 ID = 300, Checked = false, Enabled = true};
		tblMenu[4] ={Text = tLang.PEEKMI.backupset_menu, ID = 400, Checked = false,  Enabled = true};
		tblMenu[5] ={Text = tLang.PEEKMI.password1_menu, ID = 500, IconID = 0, Checked = false, Enabled = true};
		tblMenu[6] ={Text = tLang.PEEKMI.idiomaset_menu, ID = 600, Checked = false, Enabled = true};    
		tblMenu[6].SubMenu= {}
		--tblMenu[5].SubMenu= {{Text = "Espanol", ID = 510, Checked = false,  Enabled = false}};
		tblMenu[7] ={Text = tLang.PEEKMI.acercadep_menu, ID = 700, Checked = false,  Enabled = true};
		

		local found_lng = File.Find("data\\lang", "*.lng", false, false)

		if(found_lng)then
			tIdiomas = {}
			for i,v in pairs (found_lng)do 
				file = io.open(v)
				local line = file:read("*l"); line = file:read("*l"); file:close()
				
				if line then
					a = line:find("\""); b = line:find("\"", a+1);
					sIdioma = line:sub(a,b); sIdioma = sIdioma:gsub("\"", "")
				
					numi = (#tblMenu[6].SubMenu)+1;
					--local ztr = v:gsub("data\\lang\\", ""); local icl  = String.Upper(String.Left(ztr, 1)); local rest = String.Right(ztr, ztr:len()-1);local v = string.gsub(icl..rest, ".lng", "")				
					local ztr = v:gsub("data\\lang\\", ""); local v = string.gsub(ztr, ".lng", "")				
					tIdiomas[tonumber("6"..tostring(numi).."0")] = v
					tblMenu[6].SubMenu[numi]={Text = sIdioma, ID = tonumber("6"..tostring(numi).."0"), Enabled = true}
					if v == sLang then
						tblMenu[6].SubMenu[numi].Checked = true
					else
						tblMenu[6].SubMenu[numi].Checked = false
					end
				end
			end
		end

		if bMostrar then
			tblMenu[2].Checked = true 
		else 
			tblMenu[2].Checked = false;
		end

		nRes = Application.ShowPopupMenu(630, 70, tblMenu, TPM_LEFTALIGN, TPM_TOPALIGN, true, true);

		if nRes == 100 then
		   DialogEx.Show("CATEGORIAS", true);
		   -- Recargo la lista de categorias
		   	PM_CATEGORIAS = database:list(PMCAT)
			-- Si hay alguna categoria seleccionada 
			if PM_CATEGORIAS then
				if nCategoriaActual > 0 then
					-- Comprobamos que el nombre de la categoria seleccionada sea diferente al de la BD y si es asi seteamos el nuevo nombre
					if PM_CATEGORIAS[nCategoriaActual] then
						if xButton.GetText("lista_categorias_btn") ~= ' ' .. PM_CATEGORIAS[nCategoriaActual].etiqueta then
							xButton.SetText("lista_categorias_btn", ' '..PM_CATEGORIAS[nCategoriaActual].etiqueta)
						end
					else
						-- DO ANYTHING .. YA NO EXISTE LA CATEGORIA SELECCIONADA
					end
				end
			end
			if bListaCategorias then
				PM.Lista("passwords_list", PM_CATEGORIAS, bListaCategorias)
			end
		elseif nRes == 200 then 
			if(Input.GetProperties("contrasena_inp").InputStyle == INPUT_PASSWORD)then
		      bMostrar = true
		      SaveSettings({mostrar = bMostrar})
		      Input.SetProperties("contrasena_inp", {InputStyle =  INPUT_STANDARD})
			else 
				bMostrar = false
				SaveSettings({mostrar = bMostrar})
				Input.SetProperties("contrasena_inp", {InputStyle = INPUT_PASSWORD})
		   end   
		elseif nRes == 400 then 
			DialogEx.Show("BACKUP", true)
		elseif nRes == 500 then 
		   DialogEx.Show("SETTINGS", true)
		   PM_DATOS 	  = database:list(PMDAT, nLastCat)

		elseif nRes >= 600 and nRes < 700 then --IDIOMA
		   for i = 1, (#tblMenu[6].SubMenu) do
		       if(tblMenu[6].SubMenu[i].ID == nRes)then
		       	  SaveSettings({language = tIdiomas[nRes]})
		       	  sLang = LoadSettings("language")

		       	  local exec, msg = pcall(lang.set)

		       	  if not exec then
		       	  	logerror(msg)
		       	  end

		       	  --PEEKMI.OnPreload("PEEKMI")
		       	  --INIFile.SetValue(sFileCFG, "general", "language", tblMenu[5].SubMenu[i].Text);
		       end
		   end     
		elseif nRes == 700 then -- INFO 
		       DialogEx.Show("ABOUT", true, nil, nil);
		       
		end

		if descarga_finalizada then
				sObjeto = "progreso"
				Image.SetVisible(sObjeto, false)
				Image.SetVisible(sObjeto.."1", false)
				Image.SetVisible(sObjeto.."2", false)
				Paragraph.SetVisible(sObjeto.."_pg", false)
		end

		ListBoxEx.SelectItem("passwords_list", ListBoxEx.GetSelectedItem("passwords_list"), true)

		Page.Redraw();
		Image.SetOpacity(this, 70);
		Image.Load(this, "datos\\tema\\button.search.png");
		Page.StartTimer(1, 1)
	end,
	
	OnEnter = function (this)
		Image.Load(this, "data\\gui\\on_config.png");
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.config_img_Tooltip)
		Page.StopTimer(2)
	end,
	
	OnLeave = function (this)
		Image.Load(this, "data\\gui\\config.png");
		Page.StartTimer(500, 2)
	end,
}

lista_categorias_btn = {
	OnClick = function (this)
		-- !Esto lo hacemos para que no se eliminen los campos si esta editando un item
		if not bListaCategorias then
			PM.BorrarInputs("buscar_inp")
		-- clear category name		
			Paragraph.SetVisible("categoria_pg", false)
			Image.SetVisible("categoria_img", false)
			Paragraph.SetVisible("nombrecategoria_pg", false)
		-- end
	
		end
		
		PM.Buttons(true,false,false)
		Paragraph.SetText("guardaren_pg", tLang.EscogeCategoria)
		xButton.SetVisible(this, false)

		bListaCategorias = true;

		PM_CATEGORIAS = database:list(PMCAT)
		PM.Lista("passwords_list", PM_CATEGORIAS, bListaCategorias)
		CheckBox.SetEnabled("ordenar_chk", false);
	end,

	OnEnter = function (this)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.lista_categorias_btn_Tooltip)
		Page.StopTimer(2)
	end,

	OnLeave = function (this)
		Page.StartTimer(500, 2)
	end,
}

passwords_list = {
	
	OnCreate = function (this)
		PM_CATEGORIAS = database:list(PMCAT)
		
		sLastCat = tLang.TodasCategorias

		if PM_CATEGORIAS and nLastCat <= #PM_CATEGORIAS then
			for i,v in pairs (PM_CATEGORIAS) do
			   if v.recordid == nLastCat then   	
					sLastCat = v.etiqueta
			   end
			end
		else
			nLastCat = 0
		end
		--PM_DATOS = new (database, database:list("PM_DATOS"), nLastCat)
		PM_DATOS = new (database, database:list("PM_DATOS", nLastCat))
		PM_DATOS.table = "PM_DATOS"

		PM.Lista(this, PM_DATOS, false, bSort)
		xButton.SetText("lista_categorias_btn", " " .. sLastCat);
	end,

	OnSelect = function (this, e_Index)
		sID = ListBoxEx.GetItemData(this, e_Index) -- Saca el 'RecordID'
		nID = tonumber(sID)
		nSelC = nLastCat

		if not(bEditando)then
			-- || SI NO ESTAMOS AGREGANDO O EDITANDO NADA...
			if not(bListaCategorias) then
			   -- || SI NO ESTAMOS DENTRO DE LA LISTA DE CATEGORIAS...
			   PM.Buttons(true, true, true);
			   n = 1
			   while PM_DATOS[n] do
			   	if PM_DATOS[n].recordid == tonumber(sID) then
			   		etiqueta		= PM_DATOS[n].etiqueta
			   		sitioweb		= PM_DATOS[n].sitioweb				sitioweb   = (sitioweb) -- sitioweb   = crypto(sitioweb  , PM_pass, DECODE)
			   		usuario 		= PM_DATOS[n].usuario				usuario    = crypto(usuario	, PM_pass, DECODE)
			   		contrasena	= PM_DATOS[n].password				contrasena = crypto(contrasena, PM_pass, DECODE)
			   		comentario  = PM_DATOS[n].comentario			comentario = crypto(comentario, PM_pass, DECODE)
						categoria   = PM_DATOS[n].categoria				categoria  = tonumber(categoria)
			   		--nLastCat		= categoria
			   		break
			   	end
			   	n = n + 1
			   end
			   
			   if PM_CATEGORIAS then
				   for i,v in pairs (PM_CATEGORIAS) do
			   			if v.recordid == categoria then   	
			   				sLastCat = v.etiqueta 			-- RECORRE LA TABLA Y BUSCA EL NOMBRE DE LA CATEGORIA ACTUAL
			   			end
				   end
				end
				PM.BorrarInputs("buscar_inp")
				
			   Input.SetText("etiqueta_inp", etiqueta);
			   Input.SetText("sitioweb_inp", sitioweb);
			   Input.SetText("contrasena_inp", contrasena);
			   Input.SetText("nombreusuario_inp", usuario);
			   Input.SetText("comentarios_inp", comentario);

			   if categoria and tonumber(categoria) > 0 then 
			     	if String.Length(sLastCat) > 18 then
			     		-- || SI ES > 18 RECORTAMOS LOS CARACTERES EN EL STRING.
			     	   sLastCat = String.Left(sLastCat, 19);
			     	   sLastCat = sLastCat .."...";
			     	end
			     	Paragraph.SetText("nombrecategoria_pg", sLastCat); 
			     	Paragraph.SetVisible("nombrecategoria_pg", true);Paragraph.SetVisible("categoria_pg", true);Image.SetVisible("categoria_img", true);
			   else
			   	Paragraph.SetVisible("nombrecategoria_pg", false);Paragraph.SetVisible("categoria_pg", false);Image.SetVisible("categoria_img", false);
			   end
			else
				-- || SI ESTAMOS DENTRO DE LA LISTA DE CATEGORIAS...

				PM_DATOS = database:list(PMDAT, nID)
				PM.Lista(this, PM_DATOS, false, bSort)
			   if nID > 0 then
			   	for i,v in pairs (PM_CATEGORIAS) do
		   			if v.recordid == nID then   	
		   				sLastCat = v.etiqueta
		   				nLastCat = nID
		   			end
					end
				else
					sLastCat = tLang.TodasCategorias
					nLastCat = 0
				end
				if nLastCat ~= 0 then
					Paragraph.SetText("nombrecategoria_pg", sLastCat)
				end
				CheckBox.SetEnabled("ordenar_chk", true);
				xButton.SetText("lista_categorias_btn", " " .. sLastCat:gsub("&", "&&"))
				xButton.SetVisible("lista_categorias_btn", true)
				SaveSettings({last_cat = nLastCat})
				bListaCategorias = false;
				nCategoriaActual = nLastCat
			end 
		else
			-- || SI ESTAMOS EDITANDO O AGREGANDO ALGUN DATO...
			if not(bListaCategorias) then
			
			else
				-- || SI ESTAMOS DENTRO DE LA LISTA DE CATEGORIAS...
			   if nID > 0 then
			   	for i,v in pairs (PM_CATEGORIAS) do
		   			if v.recordid == nID then   	
		   				sLastCat = v.etiqueta
		   				--nLastCat = nID
		   			end
					end
				else
					sLastCat = tLang.TodasCategorias
					--nLastCat = 0
				end
				if nLastCat > 0 then
					Paragraph.SetText("nombrecategoria_pg", sLastCat)
				else
					Paragraph.SetText("nombrecategoria_pg", tLang.SinCategoria)
				end
			end
		end
	end,

	OnDoubleClick = function (this, e_Index)
		if not(bListaCategorias) then
			Page.ClickObject("editar_hs");
		end
	end,

	OnRightClick = function (this, e_Index)
		ListBoxEx.SelectItem("passwords_list", e_Index, true)
	end,
}

minim = {
	OnClick = function (this)
		Image.Load(this, "data\\gui\\minim.png")
		Window.Minimize(Application.GetWndHandle())
	end,

	OnEnter = function (this)
		Image.Load(this, "data\\gui\\minim2.png");
	end,

	OnLeave = function (this)
		Image.Load(this, "data\\gui\\minim.png");
	end,
}

cerrar = {
	
	OnClick = function (this)
		Window.Close(Application.GetWndHandle(), CLOSEWND_SENDMESSAGE);
	end,
	
	OnEnter = function (this)
		Image.Load(this, "data\\gui\\close2.png");
	end,

	OnLeave = function (this)
		Image.Load(this, "data\\gui\\close.png");
	end,
}

etiqueta_inp = {
	
	OnKey = function (this, e_Key, e_Modifiers)
		if(e_Key == 13)then
	   		Input.SetSelection("sitioweb_inp", 1, -1);
		end
	end,
}

cancelar_btn = {
	
	OnClick = function (this)
		PM.BorrarInputs()
		xButton.SetVisible("lista_categorias_btn", true);

		Paragraph.SetVisible("box", true)
		xButton.SetVisible("cancelar_btn", false);
		xButton.SetVisible("guardar_btn", false);

		Input.SetVisible("etiqueta_inp", false);
		Input.SetVisible("sitioweb_inp", false);
		Input.SetVisible("nombreusuario_inp", false);
		Input.SetVisible("contrasena_inp", false);
		Input.SetVisible("comentarios_inp", false);

		----//--//----
		bNuevaEntrada    = nil
		bEditando 	     = false
		bPassCoincide 	  = true


		Paragraph.SetVisible("box", false);--Paragraph.SetVisible("titulo2", false);ComboBox.SetVisible("lista_categorias2", false);xButton.SetVisible("cancelar_btn", false);xButton.SetVisible("guardar_btn", false);

		local properties = {BackgroundColor = 14277081, ReadOnly = true} --16777215
		Input.SetProperties("etiqueta_inp", properties);
		Input.SetProperties("sitioweb_inp", properties);
		Input.SetProperties("nombreusuario_inp", properties);
		Input.SetProperties("contrasena_inp", properties);
		Input.SetProperties("comentarios_inp", properties);

		Image.Load("etiqueta_inp_img", "data\\gui\\input.png");
		Image.Load("sitioweb_inp_img", "data\\gui\\input.png");
		Image.Load("nombreusuario_inp_img", "data\\gui\\input.png");
		Image.Load("contrasena_inp_img", "data\\gui\\input.png");
		Image.Load("comentarios_inp_img", "data\\gui\\input2.png");

		Input.SetVisible("etiqueta_inp", true);
		Input.SetVisible("sitioweb_inp", true);
		Input.SetVisible("nombreusuario_inp", true);
		Input.SetVisible("contrasena_inp", true);
		Input.SetVisible("comentarios_inp", true);

		if ListBoxEx.Find("passwords_list", nSel, LBXFIND_DATA) then
			--ListBoxEx.SelectItem("passwords_list", ListBoxEx.Find("passwords_list", nSel, LBXFIND_DATA)[1], true)
		end

		CheckBox.SetEnabled("ordenar_chk", true)

		local tT = ListBoxEx.Find("passwords_list", nSelC, LBXFIND_DATA)

		if tT then
			ListBoxEx.SelectItem("passwords_list", tT[1], true);
		end

		if ListBoxEx.Find("passwords_list", nSel, LBXFIND_DATA) then
			ListBoxEx.SelectItem("passwords_list", ListBoxEx.Find("passwords_list", nSel, LBXFIND_DATA)[1], true)
		end
	end,

	OnEnter = function (this)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.cancelar_btn_Tooltip)
		Page.StopTimer(2)
	end,

	OnLeave = function (this)
		Page.StartTimer(500, 2)
	end
}

guardar_btn = {
	
	OnClick = function (this)
		----------------------------------------------------------------------------------------------------
		---- PREPARAR LOS DATOS (EN LOS INPUTS) PARA GUARDAR:

		etiqueta 	= Input.GetText("etiqueta_inp")
		sitioweb 	= tourl(Input.GetText("sitioweb_inp"))		sitioweb 	= (sitioweb)
		usuario 		= Input.GetText("nombreusuario_inp")		usuario  	= crypto(usuario 	  , PM_pass, ENCODE)
		password 	= Input.GetText("contrasena_inp")			password 	= crypto(password	  , PM_pass, ENCODE)
		comentarios = Input.GetText("comentarios_inp")			comentarios = crypto(comentarios, PM_pass, ENCODE)
		categoria	= ListBoxEx.GetItemData("passwords_list", ListBoxEx.GetSelectedItem("passwords_list"))
		-----------------------------------------------------------------------------------------------------
		error = false
		-----------------------------------------------------------------------------------------------------

		if etiqueta:gsub(" ", "") == "" then
			error = "NOETIQUETA"
		else
			--bListaCategorias = false
		end

		if not error then
			if bEditando and bNuevaEntrada then
				-- || SI ESTAMOS AGREGANDO ITEMS
				bGuardado, sError = database:insert(PMDAT, {etiqueta, sitioweb, usuario, password, comentarios, categoria})
			else
				bGuardado, sError = database:update(PMDAT, {etiqueta, sitioweb, usuario, password, comentarios, categoria}, nSel)
			end
			
			if not bGuardado then
				--mensaje(sError)
			end
			
			PM_DATOS = database:list(PMDAT, nLastCat)
			Page.ClickObject("cancelar_btn")
		else
			if error == "NOETIQUETA" then
				msg = Mensaje(tLang.Noetiqueta1, tLang.Noetiqueta2, ERRORMSG)
			end
		end
	end,

	OnEnter = function (this)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.guardar_btn_Tooltip)
		Page.StopTimer(2)
	end,

	OnLeave = function (this)
		Page.StartTimer(500, 2)
	end,
}

ordenar_chk = {
	
	OnClick = function (this)
		local iData = ListBoxEx.GetItemData("passwords_list", ListBoxEx.GetSelectedItem("passwords_list"))

		if CheckBox.GetChecked(this) == true then
			bSort = true
			ListBoxEx.Sort("passwords_list", LBXSORT_ASC);
		else
			bSort = false
			PM.Lista("passwords_list", PM_DATOS, false, bSort)
		end

		if iData ~= "" then
			local tData = ListBoxEx.Find("passwords_list", iData, LBXFIND_DATA)
			ListBoxEx.SelectItem("passwords_list", tData[1], true)
		end
		SaveSettings({ordenar = bSort})
	end,

	OnEnter = function (this)
		Paragraph.SetText("_barra_estado", tLang.PEEKMI.ordenar_chk_Tooltip)
		Page.StopTimer(2)
	end,

	OnLeave = function (this)
		Page.StartTimer(500, 2)	
	end,
}

working_hs = {
	
	OnClick = function (this)
		if not bEditando then
			PM.Buttons(true, false, false)
			ListBoxEx.SelectNone("passwords_list")
			PM.BorrarInputs("buscar_inp")
		end
	-- clear category name		
		Paragraph.SetVisible("categoria_pg", false)
		Image.SetVisible("categoria_img", false)
		Paragraph.SetVisible("nombrecategoria_pg", false)
	-- end
		Page.SetFocus("PEEKMI")
	end
}


DIALOGO = {
	OnPreload = function (this)
		_boton = false

		if _tipomsg == ADVERTEN then
			sIMG = sf.ADVER32
			xButton.SetVisible("aceptar_btn", true)
		elseif _tipomsg == ERRORMSG then
			sIMG = sf.ERROR32
			xButton.SetVisible("aceptar_btn", true)
		elseif _tipomsg == PREGUNTA then
			xButton.SetVisible("si_btn", true)
			xButton.SetVisible("no_btn", true)
			xButton.SetVisible("aceptar_btn", false)
		else
			sIMG = sf.INFO32
			xButton.SetVisible("aceptar_btn", true)			
		end

		if sIMG then
			Image.Load("mensaje_i", sIMG)
		end

		Paragraph.SetText("titulo_pg", _titulo)
		Paragraph.SetText("mensaje_pg", _mensaje)
	end,

	OnShow = function (this)
	end,

	OnTimer = function (e_ID)
	
	end,

	OnKey = function (this, e_Key, e_Modifiers)
	end,

	OnClose = voidf
}

dialogo_cerrar = {
	OnClick = function (this)
		Image.Load(this, "data\\gui\\close.png");
		xButton.SetVisible("si_btn", false);
		xButton.SetVisible("no_btn", false);
		xButton.SetVisible("aceptar_btn", false);
		DialogEx.Close();
	end
}

dialogo_si = {
	OnClick = function (this)
		_boton = true
		DialogEx.ClickObject("cerrar")
	end
}

dialogo_no = {
	OnClick = function (this)
		DialogEx.ClickObject("cerrar")
	end
}

dialogo_aceptar = {
	OnClick = function (this)
		_boton = true
		DialogEx.ClickObject("cerrar")
	end
}