-- module ("luaf",  package.seeall)

-- ESTE SORT NO FUNCIONA BIEN CON MINUSCULAS
-- Funciones en este modulo:
-- qsort - sort, urlreplace, tourl, tdiff

function voidf (...) return nil end

function class (t, t2)
  local ret_table = {
    get  = function(self, sval)
      return self[sval]
    end,
    set = function (self, sval, sdat)
      self[sval] = sdat
    end
  }
  for k,v in pairs (t) do
    if t2 and t2[k] then
      ret_table[k] = t2[k]
    else
      ret_table[k] = v
    end
  end
  if t2 then
    for k,v in pairs(t2) do
      ret_table[k] = v
    end
  end
  setmetatable (ret_table, {
  __call = function (self, ...)
    return class(self, arg[1])
  end,
  })
  
  if ret_table.init then 
    ret_table:init()
  end
  
  return ret_table
end

new = class

function logerror(b)
  local a,c,d,f
  if b == "__NOREPORT__" then return false end
  local a,f = "Error en: ", "pm_errors.log"
  
  if _IR_ProductID then -- Verificamos si estamos ejecutando AMS asi evitamos errores al usar la funcion en lua puro
    a = a..Debug.GetEventContext().."\n"
  end
  
  local file = io.open(f, "a+")
  
  if not file then
    file = io.output(f)
  end
  
  file:setvbuf("no") -- Desactivamos el buffering; the result of any output operation appears immediately. 
  c = "Hora: "..os.date("%c") --.. "\t\tVersion: " .. sVERSION
  d = "\n"..a..b.."\n\n"
  file:write(c..d)
  -- Pienso que es mejor no cerrar el archivo de logs para que en ejecución solo sea modificado por la aplicación, sin embargo...
  if bTHEDARY then
    mensaje(c..d)
  end
  print(c..d)
  file:close()
end

-- exec= xpcall(f, logerror)
-- if exec then
--    -- Ejecucion correcta
-- end

-- exec, result = pcall(fun)

-- if not status then
--    --print ("log: \n".. result.."\n")
--    logerror(result)
-- end


function delim(str, d)
   local a,t,c = 0, {}
   if not d then d = '|' end
   repeat
      b = str:find(d, a)
      if b then
         c = str:sub(a, b-1)
         a = b +1
      else
         c = str:sub(a, #str)
      end
      t[#t+1] = c
   until b == nil 
   return t
   -- Llamada: delim "thedary|thd" o delim("thedary, dario, cano",',')
end

function lua_dostring(...)
        --Debug.ShowWindow(true);
        local b, r = pcall(function(...)
                return loadstring(arg[1])();
        end, ...);
        local st = (b==true) and (r~= nil) and "Result: "..r or (b==false) and "Error: "..r or "";
        if st ~= "" then
          print(st.."\r\n")
          return st.."\r\n"--Debug.Print(st.."\r\n");
        end
end

function dof( ... )
  local tExts = {".lua", ".lib"}
-- Si existen argumentos proceder
  if #arg > 0 then -- Si arg es mayor que cero porque la tabla arg nunca es nil
  -- Recorremos todos los argumentos
    for n, sFile in ipairs (arg) do
    -- Abrimos el archivo
      local file, error = io.open(sFile)
    -- Si hay error, es porque no se puede leer ese archivo
      if not error then
        file:close()
        --pcall(dofile, sFile))
        dofile(sFile)
      else
      -- Intentamos abrirlo colocandole al final todas las extensiones soportadas en la tabla (tExts)
      error = false
        for i, ext in pairs (tExts) do
          file, error = io.open(sFile..ext)
          if not error then 
            file:close()
            --pcall(dofile, sFile))
            dofile(sFile..ext)
            break;
          end
        end
      end
      
      if not error then
        return true
      else
        return false, "El modulo "..sFile.."No existe"
      end
    end -- endfor
  end
end

--[[
function dof(...)
  if arg then
    for n, sFile in pairs (arg) do
    bLoaded, sError = pcall(dofile, sFile)
    if bLoaded then
      return true
    end
    if not bLoaded then
    -- Intentamos cargar el modulo colocandole extension .lib y .lua
      if pcall(dofile, sFile..".lua") then
        return true
      elseif pcall(dofile, sFile..".lib") then
        return true
      else
        return false, "Error cargando el modulo: " .. sFile .. "\n\n\t" .. sError
      end
    end
    end
  else
    print("No hay argumentos")
  end
end]]

function qsort(x,l,u,f)
 if l<u then
  local m=math.random(u-(l-1))+l-1	-- choose a random pivot in range l..u
  x[l],x[m]=x[m],x[l]			-- swap pivot to first position
  local t=x[l]				-- pivot value
  m=l
  local i=l+1
  while i<=u do
    -- invariant: x[l+1..m] < t <= x[m+1..i-1]
    if f(x[i],t) then
      m=m+1
      x[m],x[i]=x[i],x[m]		-- swap x[i] and x[m]
    end
    i=i+1
  end
  x[l],x[m]=x[m],x[l]			-- swap pivot to a valid place
  -- x[l+1..m-1] < x[m] <= x[m+1..u]
  qsort(x,l,m-1,f)
  qsort(x,m+1,u,f)
 end
end

function sort(t)
	r = qsort(t, 1, #t, function (t, i) return t < i end)
	return r;
end

tourl = function(texturl)
	local protocol = string.find(texturl, ":/", 1)
	if(protocol==nil)then
		texturl = "http://"..texturl
	elseif(protocol==1)then
		texturl = "http"..texturl
	end

	texturl = string.gsub(texturl, " ", "")
	
	repeat 
		texturl = string.gsub(texturl, "//", "/")
   	   	found = string.find(texturl, "//", 1)
	until  found == nil
	
	texturl = string.gsub(texturl, ":/", "://")

return texturl
end

tobool = function(sText)
    --if(sText == 1 ) or (sText == "true")then
    if sText == "true" or sText == true then
      return true;
  --elseif(sText == 0 ) or (sText == "false")then
    elseif sText == "false" or sText == false or sText == "" then
      return false;
    end
end

tdiff = function (t1, t2)
         local value = false;
         if(#t1 ~= #t2)then
            value = true;
         else
            n = 0
            repeat 
            n = (n+1)
            	if(t1[n]~=t2[n])then
            	   value = true;
            	end
            until #t2
         end
   return value
end

function string.asc(sstr)
  for i = 1, 255 do
    if string.char(i) == sstr then
        --print(i .. " = "..sstr)
        return i .. " = "..sstr
    end
  end
end

function string.spa(self)
  self = string.gsub(self, "Á", "\181")
  self = string.gsub(self, "á", "\195")--"\160")
  self = string.gsub(self, "É", "\144")
  self = string.gsub(self, "é", "\130")
  self = string.gsub(self, "Í", "\214")
  self = string.gsub(self, "í", "\161")
  self = string.gsub(self, "Ó", "\224")
  self = string.gsub(self, "ó", "\162")
  self = string.gsub(self, "Ú", "\233")
  self = string.gsub(self, "ú", "\163")
  self = string.gsub(self, "Ñ", "\165")
  self = string.gsub(self, "ñ", "\164")
  return self
end