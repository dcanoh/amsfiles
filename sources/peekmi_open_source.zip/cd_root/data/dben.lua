--[[ dben.lua : PeekMi Library 
	 Database Engine = Este archivo actuara como mediador entre el motor de base de datos y el lenguaje en este caso lua
	 
	 table 		  = Listar(PMDAT, 1)	
	 bool  		  = CrearDB("file.db")
	 bool, string = Guardar(PMDAT, NUEVO, 7, {"eti", "web", "user", "pass", "comme", "3"})
	 
	 Eliminar(PMCAT, 1)

   LA VARIABLE sFileDB DEBE ESTAR DEFINIDA, ESTE ES EL ARCHIVO DE BASE DE DATOS
]]

sFileDB = "pm.db"

require "luasql.sqlite3"

----------------------
-- CONSTANTES GLOBALES
PMDAT  = 1
PMCAT  = 2
PMKEY  = 3

ENCODE = 1
DECODE = 2

EDITAR = false
NUEVO  = true
----------------------
function BetaToPeekMi(sFileDB)
  bNumeroExiste = false
  env = luasql.sqlite3()
  con = env:connect(sFileDB)
  cur1 = assert (con:execute("SELECT * FROM PM_SYSTEM"))
  

  if cur1 then
    for i,v in pairs (cur1:getcolnames()) do
      if v == "numero" then
        bNumeroExiste = true
      end
    end
  cur1:close()
  end

  if not bNumeroExiste then
    con:execute("ALTER TABLE 'PM_SYSTEM' RENAME to 'PM_SYSTEM_BETA'")
    con:execute("CREATE TABLE 'PM_SYSTEM' ('numero' INTEGER PRIMARY KEY, 'key' text)")

    cur2 = assert (con:execute"SELECT key FROM PM_SYSTEM_BETA")
    
    if cur2 then
      row = cur2:fetch ({}, "a")
      
      while row do
          con:execute(string.format("INSERT INTO PM_SYSTEM ('key') VALUES('%s')", row.key))
          break
      end
    cur2:close()
    end
  end
  con:close()
  env:close()
end

function CrearDB(sFile)
	--res = con:execute"DROP TABLE people"
	env = luasql.sqlite3()
	con = env:connect(sFile)
	res = assert (con:execute("CREATE TABLE 'PM_DATOS' ('numero' INTEGER PRIMARY KEY, 'etiqueta' text, 'sitioweb' text, 'usuario' text, 'password' text, 'comentarios' text, 'categoria' text)"))
  	res = assert (con:execute("CREATE TABLE 'PM_CATEGORIAS' ('numero' INTEGER PRIMARY KEY, 'etiqueta' text)"))
  	res = assert (con:execute("CREATE TABLE 'PM_SYSTEM' 	 ('numero' INTEGER PRIMARY KEY, 'key' text)"))
	
	if res == 0 then
		return true
	else
		--return false
	end
 	con:close()
 	env:close()
end

function Listar(nTabla, sCategoria)
	error = false
	if nTabla == PMDAT then
		sTabla = "PM_DATOS"
	elseif nTabla == PMCAT then
		sTabla = "PM_CATEGORIAS"
	elseif nTabla == PMKEY then
		sTabla = "PM_SYSTEM"
	--[[else
		sTabla = nTabla
		mensaje("Tabla personalizada")]]
	end
	local sQuery  = "SELECT * FROM "..sTabla
	local tReturn = {}
	local nCount  = 0

  if tonumber(sCategoria) then
    sCategoria = tonumber(sCategoria)
  else
    sCategoria = 0
  end
 	if sCategoria and sCategoria > 0 then
 		sQuery = sQuery.." WHERE categoria LIKE '"..tostring(sCategoria).."'"
 	end
 	
 	-- file:///C:/Program%20Files/Lua/5.1/docs/luasql/examples.html

 	env = luasql.sqlite3()
	con = env:connect(sFileDB)
	cur = con:execute(sQuery)
 	row = cur:fetch({}, "a")
 	--* ESTO NECESITA REVISARSE
 		-- Comprobacion de errores en el cursor, cuando ejecutemos algun query
 	--[[if not cur then 
 		error = "Error ejecutando el Query:\n"..sQuery
 	else
 		row = cur:fetch({}, "a")
 	end	]]
 	-- POR AHORA LO DEJAMOS ASI
 	
 	if cur then
		while row do
  			nCount = nCount + 1
  			if nTabla == PMDAT then
  				tData = {
  					 	recordid   = tonumber(row.numero),
  				 		etiqueta   = row.etiqueta,
  				 		sitioweb   = row.sitioweb,
  				 		usuario    = row.usuario,
  				 		password   = row.password,
  				 		categoria  = tonumber(row.categoria),
  				 		comentario = row.comentarios
  						}
  			elseif nTabla == PMCAT then
  				tData = {
  					 	recordid   = tonumber(row.numero),
  				 		etiqueta   = row.etiqueta,
  						}
  		 	elseif nTabla == PMKEY then
  				tData = {
  				 		recordid   = tonumber(row.numero),
  				 		key   = row.key,
  						}
  			end
  			tReturn[nCount] = tData
  			row = cur:fetch (row, "a")
		end
	cur:close()
	end
 	
 	con:close()
 	env:close()

	if nCount == 0 then
		tReturn = nil
	end
	if not error then
		erm = "No hubo error"
	end
	return tReturn, erm
end

function Guardar(nTabla, bDo, nLike, ...)
  local tLista  = {}

  if bDo == EDITAR then
    if nTabla == PMDAT then
      sQuery = "UPDATE PM_DATOS SET etiqueta ='%s', sitioweb ='%s', usuario ='%s', password ='%s', comentarios ='%s', categoria ='%s' WHERE numero LIKE '"..tostring(nLike).."'"
    elseif nTabla == PMCAT then
      sQuery = "UPDATE PM_CATEGORIAS SET etiqueta ='%s' WHERE numero LIKE '"..tostring(nLike).."'"
    elseif nTabla == PMKEY then
      sQuery = "UPDATE PM_SYSTEM SET key = '%s' WHERE numero LIKE '"..tostring(nLike).."'"
    end
  else
      if nTabla == PMDAT then
        sQuery = "INSERT INTO PM_DATOS ('etiqueta', 'sitioweb', 'usuario', 'password', 'comentarios', 'categoria') VALUES('%s', '%s', '%s', '%s', '%s', '%s')"
      elseif nTabla == PMCAT then
        sQuery = "INSERT INTO PM_CATEGORIAS ('etiqueta') VALUES('%s')"
      elseif nTabla == PMKEY then
        sQuery = "INSERT INTO PM_SYSTEM ('key') VALUES('%s')"
      end
  end
  
  for i,v in pairs(arg) do
    if type(arg[i]) == "table" then
      tLista[i] = arg[i]
      --print(v)
    end
  end

  if arg.n == 0 then
    err, erm =  true, "No hay argumentos"
  end
 
  if not err then
    env = assert (luasql.sqlite3())
    con = assert (env:connect(sFileDB))  
    --con = assert (env:connect("D:\\PeekMi\\peekmi_0.2\\CD_Root\\data\\passmaster.db"))  

    for i, p in pairs (tLista) do
      res = assert (con:execute(string.format(sQuery,
      p[1], p[2], p[3], p[4], p[5], p[6])
      --p.etiqueta, p.sitioweb, p.usuario, p.password, p.comentarios, p.categoria)
      ))
    end
    return true
  else
    return false, erm
  end
  con:close()
  env:close()
end

function Eliminar(nTabla, nRecordID)
  if nTabla == 1 then
    sQuery = "DELETE FROM PM_DATOS WHERE numero LIKE '"..nRecordID.."'"
  elseif nTabla == 2 then
    sQuery = "DELETE FROM PM_CATEGORIAS WHERE numero LIKE '"..nRecordID.."'"
  elseif nTabla == 3 then
    sQuery = "DELETE FROM PM_SYSTEM WHERE numero LIKE '"..nRecordID.."'"
  else
    err, erm = true, "Argumento debe ser PMDAT o PMCAT o PMKEY"
  end

  if not err then 
    env = assert (luasql.sqlite3())
    con = assert (env:connect(sFileDB))  
    con:execute(sQuery)
  end

  con:close()
  env:close()
end