-- Funciones declaradas para este dialogo

function editor_cat(bEditar, sTexto)
			if(bEditar)then
				ListBoxEx.SetEnabled("categorias_list", false);
				xButton.SetVisible("nueva_btn", false);
				xButton.SetVisible("eliminarcat_btn", false);xButton.SetEnabled("eliminarcat_btn", false)
				Paragraph.SetVisible("info_pg", false);
			
				Image.SetVisible("categoria_inp_img", true);
				xButton.SetVisible("deshacer_btn", true);
				Input.SetVisible("categoria_inp", true);		
				
				Input.SetText("categoria_inp", sTexto);
				Input.SetSelection("categoria_inp", sTexto:len()+1, sTexto:len()+1);
				
				return true;
			else
				ListBoxEx.SetEnabled("categorias_list", true);
				xButton.SetVisible("nueva_btn", true);
				xButton.SetVisible("eliminarcat_btn", true);
				Paragraph.SetVisible("info_pg", true);
			
				Image.SetVisible("categoria_inp_img", false);
				xButton.SetVisible("deshacer_btn", false);
				Input.SetVisible("categoria_inp", false);
				return false;
			end
		DialogEx.Redraw();
		end

function listar_categorias(sObjeto)
	PM.BorrarInputs()
	ListBoxEx.DeleteAllItems(sObjeto);
	PM_CATEGORIAS = database:list(PMCAT)

	if PM_CATEGORIAS then
		for i, row in pairs(PM_CATEGORIAS) do
			if(row.etiqueta == "_NUEVACAT")then
				-- La '__NUEVA_CAT__' la ponemos al principio de la lista
			--	ListBoxEx.InsertItem(sObjeto, 0, "<font color=#5F5F5F face=Tahoma size=13>".. "" .."</font>", "", row.numero, row.etiqueta, 0, LBXITEM_HTML, 0);
				ListBoxEx.AddItem(sObjeto, "<font color=#5F5F5F face=Tahoma size=13>".."".."</font>", "", row.recordid, "_NUEVACAT", 0, LBXITEM_HTML, 0);
			else
				ListBoxEx.AddItem(sObjeto, "<font color=#5F5F5F face=Tahoma size=13>"..row.etiqueta.."</font>", "", row.recordid, row.etiqueta, 0, LBXITEM_HTML, 0);
			end	
		end
	end
	totalcats = ListBoxEx.GetTotalItems(sObjeto);
ListBoxEx.Redraw(sObjeto);
return totalcats;
end


CATEGORIAS = {
	OnPreload = function (this)
		lang.set()

		selcat_st = ""
		selcat_id = 0
		DialogEx.StartTimer(10, 10)
		
		deshacer_btn.OnClick("deshacer_btn")
	end,
	
	OnShow = function (this)
		--nothing to do here
	end,

	OnTimer = function (e_ID)
		if(editar_cat)then
			Paragraph.SetText("titulo_pg", tLang.CATEGORIAS.CatPresionaEnter)
		else
			Paragraph.SetText("titulo_pg", tLang.CATEGORIAS.EditorCategorias)
		end

		if ListBoxEx.GetSelectedItem("categorias_list") == 0 then
			Paragraph.SetText("info_pg", tLang.CATEGORIAS.HazDobleClick);
		end
	end,
	
	OnKey = function (this, e_Key, e_Modifiers)
		if e_Key == 27 then
			-- ARREGLADO PONIENDO ESTO EN ONPRELOAD
			--cerrarcat.OnClick("cerrarcat")
		end
	end,

	OnClose = voidf
}


cerrarcat = {
	OnClick = function (this)
		DialogEx.SetRedraw(false)
		Image.Load(this, "data\\gui\\close.png");

		xButton.SetSize("nueva_btn", 23, 22)
		xButton.SetSize("eliminarcat_btn", 23, 22)

		env = assert (luasql.sqlite3())
		con = assert (env:connect(sFileDB))  

		con:execute("DELETE FROM PM_CATEGORIAS WHERE etiqueta = '_NUEVACAT' OR etiqueta = ''")

		con:close()
		env:close()

		Paragraph.SetText("info_pg", tLang.CATEGORIAS.HazDobleClick);
		xButton.SetEnabled("eliminarcat_btn", false);

		editar_cat = editor_cat(false);
		
		--deshacer_btn.OnClick("deshacer_btn")
		DialogEx.SetRedraw(true)
		DialogEx.Close();
	end,

	OnEnter = cerrar.OnEnter,
	OnLeave = cerrar.OnLeave

}

categorias_list = {
	
	OnCreate = function (this)
		PM_CATEGORIAS = database:list(PMCAT)
		PM.Lista(this, PM_CATEGORIAS, false)
	end,

	OnSelect = function (this)
		editar_cat = editor_cat(false)
		selcat    = ListBoxEx.GetSelectedItem(this);
		selcat_id = ListBoxEx.GetItemData(this, selcat) -- ESTO ES EL NUMERO IDENTIFICADOR DE LA CATEGORIA EN LA SQL
		selcat_st = ListBoxEx.GetItemDataEx(this, selcat)
		selcat_nu = ListBoxEx.GetItemData(this, selcat)
		xButton.SetEnabled("eliminarcat_btn", true);

		nGuardadas = database:list(PMDAT, nLastCat)
		GuardadasEnCat = tLang.CATEGORIAS.GuardadasEnCat3 -- No hay

		if nGuardadas then

			if #nGuardadas == 1 then
				GuardadasEnCat = tLang.CATEGORIAS.GuardadasEnCat1 -- Hay una guardada
			elseif(#database:list(PMDAT, nLastCat) > 1)then
				GuardadasEnCat = tLang.CATEGORIAS.GuardadasEnCat2 -- hay varias guardadas
			end
		--else
			
		end

		local tCategoriasGuardadas = database:list(PMDAT, tonumber(selcat_id))
		local nTotal = 0

		if tCategoriasGuardadas then
			nTotal = #tCategoriasGuardadas 
		end

		Paragraph.SetText("info_pg", GuardadasEnCat:gsub("$NUM", nTotal))

		DialogEx.Redraw();
		DialogEx.SetFocus("CATEGORIAS");
		Page.SetFocus("CATEGORIAS");
	end,

	OnDoubleClick = function (this ,e_Index)
		editar_cat = editor_cat(true, selcat_st);
	end,
}

nueva_btn = {
	
	OnClick = function (this)
		xButton.SetSize(this, 23, 22);

		database:insert(PMCAT, {"_NUEVACAT"})

		PM_CATEGORIAS = database:list(PMCAT);

		listar_categorias("categorias_list")

		ListBoxEx.MoveItem("categorias_list", #PM_CATEGORIAS, 0);
		local tItem = ListBoxEx.Find("categorias_list", "_NUEVACAT", LBXFIND_EXDATA)
		if tItem then
			ListBoxEx.SelectItem("categorias_list", tItem[1], true);
		end
		--ListBoxEx.SetItemText("categorias_list", ListBoxEx.Find("categorias_list", "_NUEVACAT", LBXFIND_EXDATA)[1], "");
		editar_cat = editor_cat(true, "");
	end,

	OnEnter = function (this)
		xButton.SetSize(this, 77, 22);
	end,

	OnLeave = function (this)
		xButton.SetSize(this, 23, 22);
	end,
}

eliminarcat_btn = {
	
	OnClick = function (this)
		DialogEx.StopTimer() -- Timer 10
		xButton.SetSize(this, 23, 22);

		local nSel = ListBoxEx.GetItemData("categorias_list", ListBoxEx.GetSelectedItem("categorias_list")) -- Saca el 'RecordID'
		local sName = ListBoxEx.GetItemDataEx("categorias_list", ListBoxEx.GetSelectedItem("categorias_list")) -- Saca el nombre
		--local nMsg  = Mensaje(string.format('¿Deseas eliminar "%s" ?', sName), MB_ICONQUESTION, "PeekMi")
		local nMSG  = Mensaje(tLang.CATEGORIAS.EliminarCat, tLang.CATEGORIAS.EliminarCatPRE:format(sName), PREGUNTA, sf.ADVER32)
		
		if nMSG then		
			database:delete(PMCAT, nSel)
			PM.Lista("categorias_list", database:list(PMCAT), false, bSort)
		end
		DialogEx.StartTimer() -- Timer 10
	end,

	OnEnter = function (this)
		xButton.SetSize(this, 77, 22);
	end,

	OnLeave = function (this)
		xButton.SetSize(this, 23, 22);
	end,
}

categoria_inp = {
	OnKey = function (this, e_Key, e_Modifiers)
		sText = Input.GetText(this);

		ListBoxEx.SetItemText("categorias_list", selcat, "<font color=#5F5F5F face=Tahoma size=13>".. sText .."</font>");
	
	-- Si presiona ENTER
		if(e_Key == 13)then 
			Paragraph.SetText("info_pg", tLang.CATEGORIAS.HazDobleClick);

			if(sText == "")then
				deshacer_btn.OnClick(this)
			else
			-- Si hay algo escrito Guardar...
				local saved, error = database:update(PMCAT, {sText}, selcat_id)
				if not saved then
					-- error	
				end
			-- Recargo la lista de categorias
				PM_CATEGORIAS = database:list(PMCAT)
				listar_categorias("categorias_list");
			end
			editar_cat = editor_cat(false);
		end
	end,

	OnSetFocus = function (this)
		ListBoxEx.SetItemText("categorias_list", selcat, "<font color=#5F5F5F face=Tahoma size=13>".. Input.GetText(this) .."</font>");
	end,
}

deshacer_btn = {
	OnClick = function (this)
		ListBoxEx.SetItemText("categorias_list", selcat, "<font color=#5F5F5F face=Tahoma size=13>".. selcat_st .."</font>");

		env = assert (luasql.sqlite3())
		con = assert (env:connect(sFileDB))  

		con:execute("UPDATE PM_CATEGORIAS SET etiqueta = '".. selcat_st .."' WHERE numero = '".. selcat_id .."'")
		con:execute("DELETE FROM PM_CATEGORIAS WHERE etiqueta = '_NUEVACAT' OR etiqueta = ''")

		con:close()
		env:close()
		 
		listar_categorias("categorias_list");
		--PM_CATEGORIAS = database:list(PMCAT)
		--PM.Lista("listacategorias", PM_CATEGORIAS, false)
		editar_cat = editor_cat(false);
		Paragraph.SetVisible("info_pg", true);
	end,
}
