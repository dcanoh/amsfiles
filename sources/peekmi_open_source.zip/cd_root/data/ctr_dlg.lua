PM_CONTROL = {
	OnPreload = function (this)
		lang.set()

		tDispositivos = Drive.Enumerate();
		intentos = 0;

		sArchivo = (sFileUSB)
		nCount   = (0);

		repeat
			nCount = nCount + 1;
		   sDispositivoActual = (tDispositivos[nCount])
		   sArchivoContrasena = (sDispositivoActual..sFileUSB)
		   
		   if(Drive.GetType(sDispositivoActual) == DRIVE_REMOVABLE) and (sDispositivoActual ~= "A:\\")then -- La constante DRIVE_REMOVABLE es igual a 2
				if File.Run("cmd.exe", "/k dir f:\\ & exit", "", SW_HIDE, true) == 0 then
					if(File.DoesExist(sArchivoContrasena))then
						sKey1   = Crypto.MD5DigestFromString(crypto(Drive.GetInformation(sDispositivoActual).SerialNumber, Drive.GetInformation(sDispositivoActual).SerialNumber, ENCODE))
						sKey2   = PM_drive
						
						if(sKey1 == sKey2)then
							sContrasenaEncriptada = String.Replace(TextFile.ReadToString(sArchivoContrasena), 'DCano_PM7', '', true);
							sContrasena			    = crypto(sContrasenaEncriptada, Drive.GetInformation(sDispositivoActual).SerialNumber, DECODE)
							
							if(Crypto.MD5DigestFromString(crypto(sContrasena,sContrasena, ENCODE)) == PM_pass)then
			             	Paragraph.SetText("info_pg", tLang.PM_CONTROL.info_pg2)
			             	Image.SetVisible("password_inp_img", false)
			             	xButton.SetVisible("unlock_btn", false)
			             	Input.SetVisible("contrasena_inp2", false)
			             	bUSBKey = true
			               DialogEx.Redraw()
			               DialogEx.StartTimer(7, 20)
			          	end
			          end
			     end
		       end
		    end
		   until nCount == #tDispositivos

		if not(bUSBKey)then
			DialogEx.StartTimer(10, 10)
		end
	end,

	OnShow = function (this)
		Input.SetSelection("contrasena_inp2", 1, -1);
	end,

	OnTimer = function (e_ID)
		if(e_ID == 10)then
		   DialogEx.StopTimer(e_ID)
		   tDispositivos = Drive.Enumerate();
		   sArchivo = (sFileUSB)
		   nCount   = (0);
		   repeat
		    nCount = nCount + 1;
		    sDispositivoActual = (tDispositivos[nCount]);
		    sArchivoContrasena = (sDispositivoActual..sFileUSB);
		    if(Drive.GetType(sDispositivoActual) == DRIVE_REMOVABLE) and (sDispositivoActual ~= "A:\\")then -- La constante DRIVE_REMOVABLE es igual a 2
		       if(File.DoesExist(sArchivoContrasena))then
		          sKey1   = Crypto.MD5DigestFromString(crypto(Drive.GetInformation(sDispositivoActual).SerialNumber, Drive.GetInformation(sDispositivoActual).SerialNumber, ENCODE))
		          sKey2   = PM_drive;
		          if(sKey1 == sKey2)then
		             sContrasenaEncriptada = String.Replace(TextFile.ReadToString(sArchivoContrasena), 'DCano_PM7', '', true);
		             sContrasena			  = crypto(sContrasenaEncriptada, Drive.GetInformation(sDispositivoActual).SerialNumber, DECODE)
		          	 if(Crypto.MD5DigestFromString(crypto(sContrasena,sContrasena, ENCODE)) == PM_pass)then
		             	Paragraph.SetText("info_pg", tLang.PM_CONTROL.info_pg2)
		             	Image.SetVisible("password_inp_img", false);
		             	xButton.SetVisible("unlock_btn", false);
		             	Input.SetVisible("contrasena_inp2", false)
		             	bUSBKey = true;
		               DialogEx.Redraw()
		               DialogEx.StartTimer(7, 20);
		          	 end
		          end
		       end
		    end
		   until nCount == #tDispositivos
		if not(bUSBKey)then
		   DialogEx.StartTimer(10, e_ID);
		end
		end

		if(e_ID == 20)then
		   DialogEx.StopTimer(e_ID)
		   Paragraph.SetVisible("status_pg", false)
		   Image.SetVisible("status_img", false)
		   Input.SetVisible("contrasena_inp", false);

		   if(bUSBKey)then
		      for i = 1, 100 do
		      	PM.Progreso("progreso", i)
		      	Application.Sleep(7)
		      	--PM.Progreso("progreso", 114, 250, i)
			  end
		      PM_pass = sContrasena
		      DialogEx.Close()
		   end
		end
	end,

	OnKey = function (e_Key, e_Modifiers)
		if e_Modifiers.alt and e_Key == 115 then
			os.exit()
		end
	end,

	OnClose = function (this)
		if sContrasena ~= PM_pass then
			bMostrarLoginDeNuevo = true
		end
	end
}

contrasena_inp2 = {
	OnKey = function (this, e_Key)
		if(e_Key == 13)then
		   DialogEx.ClickObject("unlock_btn")
		end
	end
}

unlock_btn = {
	OnClick = function (this)
		sContrasena = Input.GetText("contrasena_inp2");

		if(Crypto.MD5DigestFromString(crypto(sContrasena, sContrasena, ENCODE)) == PM_pass)then
		   PM_pass = sContrasena;
		   DialogEx.Close();
		else
		   if not(intentos == 7)then
		      intentos = (intentos + 1)
		   else
		      os.exit()
		   end
		   DialogEx.StartTimer(2500, 20);
		   --Paragraph.SetText("status_pg", tLang.PM_CONTROL.status_pg)
		   Image.SetVisible("status_img", true);
		   Paragraph.SetVisible("status_pg", true);
		   Input.SetSelection("contrasena_inp2", 1, -1);
		end
	end
}