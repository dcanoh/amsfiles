--[[ luams_a.lua : PeekMi Library 
	 Lua AMS = Funciones que necesitan expresamente ser ejecutadas desde AMS
	 string = LoadSettings(language)
	 SaveSettings({language = "Spanish", last_cat = 0})
	 string = crypto("string", "pass", ENCODE-DECODE)
]]

require "data\\luaf"

----------------------
-- CONSTANTES GLOBALES
MERROR = 16
MQUEST = 32
MINFOR = 64
----------------------


PM.Needed = function ()
	-- Archivos necesitados
end

ams = {}

function ams.getform( ... )
	local current = Application.GetCurrentDialog()
	if current == '' then current = Application.GetCurrentPage() end
	return current
end

function ams.getevent()
	local current = Application.GetCurrentDialog()
	if current == '' then current = Application.GetCurrentPage() end
	local context = Debug.GetEventContext():gsub("->", ''):gsub(current, '')
	context = context:sub(3, context:len())
	return context
end


crypto = function(sText, sKey, nOption)
  if nOption == ENCODE then
    sReturn = Crypto.BlowfishEncryptString(sText, sKey, 0)
  elseif nOption == DECODE then
    sReturn = Crypto.BlowfishDecryptString(sText, sKey)
  end
  return sReturn
end

mensaje = function(sMensaje, nTipo, sTitulo)
	sMensaje = tostring(sMensaje)
	if not(sTitulo)then sTitulo = "";end
	if _IR_ProductID then
		if nTipo == 32 then
			return Dialog.Message(sTitulo, sMensaje, MB_YESNO, MB_ICONQUESTION)
		else
			Dialog.Message(sTitulo, sMensaje, nTipo)
		end
	else
		print(sMensaje, sTitulo)
	end
end

LoadSettings = function (sValue)
	if not File.DoesExist(sFileCFG) then
		TextFile.WriteFromString(sFileCFG, "")
	end
	tReturn = INIFile.GetValueNames(sFileCFG, "general")
		if tReturn then
			for i,value in pairs (tReturn)do
				if(sValue == value)then
					Data = INIFile.GetValue(sFileCFG, "general", value)
					if tonumber(Data) then
						Data = tonumber(Data)
					end
					if tobool(tData) ~= nil then
						Data = tobool(Data)
					end
					break
				else
					Data = false
				end
			end
		else
			Data = false
		end
return Data
end

SaveSettings = function(tConfig)
	if(tConfig)then
		for value, data in pairs(tConfig) do
			INIFile.SetValue(sFileCFG, "general", value, tostring(data));
		end
	end
end

function lang_get (...)
	if #arg > 0 then
		ret = {PM_CONTROL = {}, PEEKMI = {}, CATEGORIAS = {}}
		for i,a in ipairs(arg) do
		--ret[i] = arg[i]:spa()
			for k,v in pairs(a) do
				if type(v) == "table" then
					for x,y in pairs(v) do
						ret[k][x] = a[k][x]--:spa()
					end
				else
					ret[k] = a[k]--:spa()
				end
			end
		end
		return ret
	else
		return false
	end	
end

function call(type, func, args)
	if type == OBJECT_BUTTON then 
		object = "Button"
	elseif type == OBJECT_LABEL then 
		object = "Label"
	elseif type == OBJECT_PARAGRAPH then 
		object = "Paragraph"
	elseif type == OBJECT_INPUT then 
		object= "Input"
	elseif type == OBJECT_RADIOBUTTON then 
		object=("RadioButton")
	elseif type == OBJECT_CHECKBOX then 
		object=("CheckBox")
	elseif type == OBJECT_XBUTTON then 
		object=("xButton")
	end
	
return object.."."..func.."("..args..")"
end

lang = {
	set = function (xsLang)
		-- String de errores con el idioma
		error = false
		sError1 = "No pude cargar \""..sLang..".lng\""
		sError2 = "Hay un problema con la sintaxis del archivo de idioma. \n\nSe recomienda volver a instalar PeekMi."

		if sLang then
			sLangFile = _SourceFolder.."\\data\\lang\\"..sLang..".lng"
		end
		
		if not File.DoesExist(sLangFile) then
		-- Falta el archivo de idioma !
			mensaje("falta archivo idioma")
		else
		-- Cargamos el archivo de idioma
			--dofile(sLangFile)
			file = io.open(sLangFile)
			ing = file:read("*a")
			-- Localizamos donde se cierra la tabla
			n = ing:find("}")
			m = 0
			repeat
				m = m+1
				n = ing:find("}", n+1)
			until m == 9-- Hasta que sea nil
			
			--lua_dostring("tLang = "..ing:sub(1,n))
			
			function loadlng(sTotalRead)
				--mensaje (sTotalRead)
				--ing:sub(ing:find(";") +1
				--mensaje(  sTotalRead:sub(1, ing:find(";")) )
				st = sTotalRead:sub(1, sTotalRead:find("{")-1)
				
				local chunkvars = loadstring(st)
				--mensaje(st)
				
				setfenv(chunkvars, {move = voidf})
				xpcall(chunkvars, logerror)
				--"tLang = 0;\n"..sTotalRead:sub(1, sTotalRead:find("{")-1)xpcall(ChunkVars, logerror)
				
				chunklangstr = "tLang = "..sTotalRead:sub(ing:find("{"), #sTotalRead)
				local chunklang = loadstring(chunklangstr)
				
				setfenv(chunklang, getfenv(chunkvars))
				xpcall(chunklang, logerror)
				
				--[[
				local enobj = DialogEx.EnumerateObjects()
				
				if not enobj then
					enobj = Page.EnumerateObjects()
				end
				
				local env = {}

				for k,v in pairs(enobj) do
					env[v] = voidf
				end
				
				--setfenv(chunk, env)
				
				xpcall(chunk, logerror)
				]]--

				local env = getfenv(chunklang)
				
				if env then
					return env.tLang, chunklangstr 
				else
					return nil
				end
			end
			
			exec, tLang, lngcode = pcall(loadlng, ing:sub(1, n)) -- Llamamos con pcall para que no se corte la ejecucion si el archivo esta corrupto

			--lngcode = ing:sub(1,n)-- globalvariable
			--mensaje(lngcode)
			if not exec or not tLang then
				error = "Archivo corrupto"
				logerror("The Language file: "..sLang..".lng have syntax error.") 
			end
			
			if error then
			-- Si hay error
				if sLang == "spanish" then
					Mensaje(sError1, sError2, ERRORMSG)
				else
					SaveSettings({language = "spanish"})
					File.Run(_SourceFilename)
				end
				os.exit()
			end

			file:close()
		end
		
	-- Modificamos claves de registro
		Registry.SetValue(HKEY_CLASSES_ROOT, "PM.UpdateFile", "", tLang.OffUpdateFile, REG_SZ)

	-- Obtenemos el nombre del dialogo actual y el numero de objetos en el
		sPage = Application.GetCurrentDialog()
		tObjs = DialogEx.EnumerateObjects()
	
	-- Si están vacias significa que no hay ningun DialogEx abierto
		if sPage == "" and not sObjs then
			sPage = Application.GetCurrentPage()
			tObjs = Page.EnumerateObjects()		
		end
		sText = ""
		for i, object in pairs (tObjs) do
		-- Obtenemos el tipo de objeto
			nType = DialogEx.GetObjectType(object)
			if nType == -1 then -- sType > 0
				nType = Page.GetObjectType(object)
			end
			
			if tLang then
				sText = tLang[sPage][object]
			end
			
			--sTool = sLang[object.."_Tooltip"]:spa()
			 -- sButton "Size:03"
			if sText ~= "" and sText then
          		lua_dostring(call(nType, "SetText", '"'..object..'"'..', '..'"'..sText..'"'))
          		
          		a = lngcode:find(object); 
          		b = lngcode:find("\"", a) -- 405
          		c = lngcode:find("\"", b+1) -- 413
          		d = lngcode:sub(a,b) -- status_pg "
          		f = lngcode:sub(a,c) -- status_pg "Size 10"
          		--mensaje(f)
          		if not d:find("=") then
          			-- Es una funcion:
          			fs = f:sub(f:find(' ')+1, #f) -- "Size 10"
          			fn = fs:sub(2, fs:find(' ')-1) -- Size
          			fa = fs:sub(fs:find(' ')+1, #fs-1) -- 10
          			str = call(nType, "SetPos", "\""..object.."\"")
          			str2 = call(nType, "GetPos", "\""..object.."\"")..".X"
          			str3 = call(nType, "GetPos", "\""..object.."\"")..".Y"
          			--mensaje(fn:lower())
          			if fn:lower() == "v" or fn:lower() == "vertical" then 
          				--local chunk = loadstring(str:sub(1, #str-1) .. ',' .. str2 .. ','.. str3 .. "+" .. tonumber(fa) ..')') -- size("status_pg", "+10"          				
          				local chunk = loadstring(str:sub(1, #str-1) .. ',' .. str2 .. ','.. tonumber(fa) ..')') -- size("status_pg", "+10"          				
          				chunk()
          			elseif fn:lower() == "h" or fn:lower() == "horizontal" then 
          				--mensaje(str:sub(1, #str-1) .. ',' .. str2 .. "+" .. tonumber(fa) .. ','.. str3 ..')')
          				--local chunk = loadstring(str:sub(1, #str-1) .. ',' .. str2 .. "+" .. tonumber(fa) .. ','.. str3 ..')')
local chunk = loadstring(str:sub(1, #str-1) .. ',' .. tonumber(fa) .. ','.. str3 ..')')
          				chunk()
          			end
          			--local chunk = loadstring(string.lower(fn.."(\""..object.."\", \""..fa.."\")")) -- size("status_pg", "+10")
          			
          			--chunk()

          			
          		end


          		--objt = sText:sub(sText:sub(object), )
          		--mensaje (objt)
			end
		end
		if tLang and not error then
			return true, tLang
		end
	end,
}
