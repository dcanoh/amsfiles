require "data.luaf"

sBackupsFolder = Registry.GetValue(HKEY_CURRENT_USER, "Software\\peekmi", "BackupFolder", false)

if sBackupsFolder == '' then
	sBackupsFolder = Shell.GetFolder(SHF_MYDOCUMENTS).."\\peekmi backups"
end

Backup = {}

function tomes( ... )
	mes = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}
	n = tonumber(arg[1])
	if n then
		return mes[n]
	end
end

function mdate(sDate1, sDate2)
	-- 1: La fecha siempre debe ser yyyy-mm-dd
	-- 2: No intentar comparar yyyy-01--dd con yyyy--1--dd

	local r = false
	local t = delim(sDate1, '-')
	AViejo, MViejo, DViejo = t[1], t[2], t[3]

	local t = delim(sDate2, '-')
	ANuevo, MNuevo, DNuevo = t[1], t[2], t[3]

	if AViejo == ANuevo then
		if MViejo == MNuevo then
			if DViejo < DNuevo and DNuevo - DViejo >= 0 then
				--print ("Han pasado ".. DNuevo - DViejo .. " dias")	
				r = true
			end
		elseif MNuevo - MViejo >= 0 then
			--print ("Han pasado ".. MNuevo - MViejo .. " meses")	
			r = true
		end
	elseif ANuevo - AViejo >= 0 then
		--print ("Han pasado ".. ANuevo - AViejo .. " a�os")
		r = true
	end	
	return r
end

function Backup.Verify(sHoy, nDays)
		local tfiles = File.Find(sBackupsFolder, "*.pm_backup", true, false)
		
		if not tfiles then 
			return true -- Es Hora de hacer una copia
		end
		
		if #tfiles > 1 then
			--xButton.SetEnabled("anteriores_btn")
		end
		
		---------------------------------
		-- Encontrar el archivo mas nuevo

		mayear, mamonth, maday = 0, 0, 0

		for i,v in ipairs(tfiles) do
		 	year = delim(v:gsub("peekmi_autosave_", ''), '-')[1]:gsub(sBackupsFolder.."\\", '')
		 	year = tonumber(year)
		 	if year > mayear then 
		 		mayear = year	end
		end

		for i,sPath in ipairs(tfiles) do
		 	--v = v:sub(v:find("peekmi_autosave"), #v) -- Eliminar la ruta y dejar solo el nombre de archivo
		 	--month = tonumber(delim(v:gsub("peekmi_autosave_", ''), '-')[2])
		 	--mensaje(delim(v:gsub("peekmi_autosave_", ''), '-')[1])
		 	
		 	-- Eliminamos la ruta del contenido del string y solo dejamos el nombre de archivo:
		 	local i,e = sPath:find("peekmi_autosave_"), #sPath -- init, end
		 	local sFilename = sPath:sub(i,e)
		 	--mensaje(sFilename)
		 	-- Obtenemos solo la fecha: 
		 	sDate = sFilename:gsub("peekmi_autosave_", ''):gsub(".pm_backup", '')
			
		 	sMonth = delim(sDate, '-')[2]

		 	month = tonumber(sMonth)
		 	if month > mamonth then
		 		mamonth = month end
		end

		for i,v in ipairs(tfiles) do
		 	day = (delim(v:gsub("peekmi_autosave_", ''), '-')[3]:gsub(".pm_backup", ''))
		 	day = tonumber(day)

		 	if day > maday then
		 		maday = day end
		end

		local sLast = mayear..'-'..mamonth..'-'..maday

		if mdate(sLast, sHoy) then
			--mensaje "Es hora de copia"
			return true, sLast
		else
			--mensaje "No es necesario un backup"
			return false, sLast
		end
end

function Backup.Make( ... )
	AutoBackup = Thread {
		"AutoBackup",

		Function = function (self, ... )
			require "dben"
			sFileBackup = "peekmi_autosave_"
			PM_DATOS = database:list("PM_DATOS")
			PM_CATEGORIAS = database:list("PM_CATEGORIAS")
			PM_SYSTEM = database:list("PM_SYSTEM")
			
			if #PM_DATOS == 0 or #PM_CATEGORIAS == 0 or PM_SYSTEM == 0 then
				linda:set("AutoBackup", "!DESTROY!")
				return false -- No hacer copia
			end

			local backup = database {
				file   = sBackupsFolder.."\\pmbackup.db",
				header = sBackupsFolder.."\\pmheader",
			}

			if not Folder.DoesExist(sBackupsFolder) then
				Folder.Create(sBackupsFolder)
			end

			if not File.DoesExist(backup.file) then
				backup:create()
			end
			n = 1
			repeat
				percent = tonumber((n/ #PM_DATOS) * 100); percent = (percent / 2)
				row = PM_DATOS[n]
					
				linda:set("AutoBackup", percent) -- AutoBackup:set(n)
				backup:insert(PMDAT, {row.etiqueta, row.sitioweb, row.usuario, row.password, row.comentario, row.categoria})
				n = n + 1
				Application.Sleep(200)
			until n > #PM_DATOS
			
			n = 1
			repeat
				percent = tonumber((n/ #PM_CATEGORIAS) * 100); percent = (percent / 2) + 48
				row = PM_CATEGORIAS[n]
					
				linda:set("AutoBackup", percent) -- AutoBackup:set(n)
				backup:insert(PMCAT, {row.etiqueta})
				n = n + 1
			until n > #PM_CATEGORIAS

			n = 1
			repeat
				row = PM_SYSTEM[n]
					
				backup:insert(PMKEY, {row.key})
				n = n + 1
			until n > #PM_SYSTEM

			-- | HEADER FILE:
			file = io.open(backup.header, "w+")
			file:write(os.date().."\n"..#PM_DATOS.."\n"..#PM_CATEGORIAS)
			file:close()

			Zip.Add(sBackupsFolder.."\\peekmi_autosave.zip", {backup.file, backup.header}, false, "", 5, nil, false)
			linda:set("AutoBackup", 100)
			os.remove(backup.file)
			os.remove(backup.header)

			local dt = os.date("*t")
			File.Move(sBackupsFolder.."\\peekmi_autosave.zip", sBackupsFolder .. "\\peekmi_autosave_"..dt.year..'-'..dt.month..'-'..dt.day..".pm_backup", false);

			Application.Sleep(100)

			linda:set("AutoBackup", "!DESTROY!")
			
		end
	}

	AutoBackup:reg([[
		Page.StopTimer(e_ID)
		if linda:get("AutoBackup") ~= "!DESTROY!" then
			PM.Progreso("progreso", linda:get("AutoBackup"), "Haciendo copia de seguridad...")
			Page.StartTimer(1, e_ID)
		else				
			-- Ocultar la barra de progreso
			PM.Progreso("progreso", 100)
			-- Destruir el proceso	
			table.remove(Thread, AutoBackup.id)
			AutoBackup = nil
		end
	]])
end

function Backup.MakeFile(sFile)
	-- | HEADER FILE:
	file = io.open(_SourceFolder.."\\pmheader", "w+")
	file:write(os.date().."\n"..#PM_DATOS.."\n"..#PM_CATEGORIAS.."\n"..sVERSION)
	file:close()

	Zip.Add(sFile, {_SourceFolder.."\\pm_settings.ini", _SourceFolder.."\\data\\passmaster.db", _SourceFolder.."\\pmheader"}, false, "", 5, nil, false)
	os.remove(_SourceFolder.."\\pmheader")
end

function Backup.Restore(sFile)
	Zip.Extract(sFile, {"*.*"}, sBackupsFolder, true, true, "", 3, nil)
	Application.Sleep(500)
	File.Delete(_SourceFolder.."\\data\\passmaster.db")
	Application.Sleep(500)
	File.Move(sBackupsFolder.."\\pmbackup.db", _SourceFolder.."\\data\\passmaster.db", false)
	Application.Sleep(500)
	File.Delete(sBackupsFolder.."\\pmheader")
	Application.Sleep(500)
	File.Run(_SourceFilename)
	os.exit()
end


BACKUP = {OnPreload = voidf, OnShow = voidf, OnTimer = voidf, OnClose = voidf}

function BACKUP:OnPreload (...)
	lang.set()
	local dt = os.date("*t")
	local makebackup, last_backup = Backup.Verify(string.format("%s-%s-%s", dt.year, dt.month, dt.day))
	
	if not last_backup then
		xButton.SetEnabled("restaurar_btn", false)
	else
		xButton.SetEnabled("restaurar_btn", true)
		LaUltimaCopia = tLang.LaUltimaCopia

		if last_backup == string.format("%s-%s-%s", dt.year, dt.month, dt.day) then -- Si el ultimo backup fue hoy
			LaUltimaCopia = LaUltimaCopia:format("hoy")
		
		elseif last_backup == string.format("%s-%s-%s", dt.year, dt.month, dt.day-1) then -- Si el ultimo backup fue ayer
			LaUltimaCopia = LaUltimaCopia:format("ayer")
		else
			local tlast = delim(last_backup, '-')
			local anyo, mes, dia = tlast[1], tomes(tlast[2]), tlast[3]

			LaUltimaCopia = LaUltimaCopia:format("el "..dia.." de "..mes)
		end
		Paragraph.SetText("historial_info_pg", LaUltimaCopia)
		Paragraph.SetText("backup_pg", "peekmi_autosave_"..last_backup)
	end
	
	xButton.SetEnabled("creararchivo_btn", false)

	if bPMRESTORE then
		-- sFile lo definimos con commandlineargs
		restaurar_btn:OnClick() 
	end
end

restaurar_btn = {}

function restaurar_btn:OnClick () 
	if not bPMRESTORE  then
		sFile = sBackupsFolder.."\\"..Paragraph.GetText("backup_pg")..".pm_backup"
	end

	Zip.Extract(sFile, {"*.*"}, sBackupsFolder, true, true, "", 3, nil)

	local str = "Fecha: %s                       Hora: %s\n\nContrase�as almacenadas: %d                 Categor�as: %d"
	local thead = TextFile.ReadToTable(sBackupsFolder.."\\pmheader")
	local date  = delim(thead[1]:sub(1, 9), '/')
	local month, day, year = date[1], date[2], date[3]
	local hour  = thead[1]:sub(10, string.len(thead[1])-3)

	Paragraph.SetText("file_info2_pg", str:format(tomes(month)..' '..day.." de 20"..year, hour, thead[2], thead[3]))

	xButton.SetVisible("creararchivo_btn", false)
	xButton.SetVisible("restaurar_btn", false)
	xButton.SetVisible("anteriores_btn", false)

	Image.SetVisible("fondo2")
	Image.SetVisible("file_info_img")
	Image.SetVisible("sobreescribir_img")
	
	Paragraph.SetVisible("info_box")
	Paragraph.SetVisible("file_info_pg")
	Paragraph.SetVisible("file_info2_pg")
	Paragraph.SetVisible("sobreescribir_pg")
	Paragraph.SetVisible("sobreescribir_info_pg")

	xButton.SetVisible("iniciar_btn")
	xButton.SetVisible("cancelar2_btn")
end

iniciar_btn = {}

function iniciar_btn:OnClick( ... )
	Backup.Restore(sFile)
end

cancelar2_btn = {}

function cancelar2_btn:OnClick( ... )
	xButton.SetVisible("creararchivo_btn")
	xButton.SetVisible("restaurar_btn")
	xButton.SetVisible("anteriores_btn")

	xButton.SetVisible("iniciar_btn", false)
	xButton.SetVisible("cancelar2_btn", false)

	Paragraph.SetVisible("info_box", false)
	Paragraph.SetVisible("file_info_pg", false)
	Paragraph.SetVisible("file_info2_pg", false)
	Paragraph.SetVisible("sobreescribir_pg", false)
	Paragraph.SetVisible("sobreescribir_info_pg", false)

	Image.SetVisible("fondo2", false)
	Image.SetVisible("file_info_img", false)
	Image.SetVisible("sobreescribir_img", false)
end

creararchivo_btn = {}

function creararchivo_btn:OnClick( ... )
	local sFile = Dialog.FileBrowse(false, "Locate File", _DesktopFolder, "Archivo de recuperaci�n (*.pm_restore*)|*.pm_restore*|", "", "pm_restore", false, false)

	if sFile[1] ~= "CANCEL" then
		Backup.MakeFile(sFile[1])
	end
end

cerrarbackup = {
	OnEnter = function ( this, ... )
		Image.Load(this, "data\\gui\\close2.png");
	end,

	OnLeave = function ( this, ... )
		Image.Load(this, "data\\gui\\close.png");
	end
}

anteriores_btn ={
	OnClick = function ( ... )
		--mensaje("Respirar es arriesgar")
	end
}