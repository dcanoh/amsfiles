-- pmlib_a.lua = PeekMi Library  : 
-- Aquí serán definidas las funciones y variables utilizadas solo por PeekMi, lo hago porque algunas de estas funciones deben ser necesariamente llamadas desde AMS

-----------------------------
-- CARGAR LIBRERIAS LUA
require "lanes"
----------------------------ensa-


-----------------------------
-- DECLARAR VARIABLES
PM = {}
linda = lanes.linda()
-----------------------------
-- CONSTANTES GLOBALES
ERRORMSG = 0
ADVERTEN = 1
PREGUNTA = 2

-----------------------------
-- DEFINICION DE CLASES

Thread = {} -- Aqui definimos esta tabla primero para poder hacer el conteo 
Thread = class {
	
	init = function(self)
		if self.Function then
			linda:set(self[1], "init")
			exec = lanes.gen("*", {globals=_G}, self.Function)(self)

		end
		-- Conteo: 
		Thread[#Thread + 1] = self[1]
		self.id = #Thread
	end,
	
	reg = function (self, CODE)
		nID = self.id
		nID = nID + 70000
		local newcode = "\n".."if e_ID == "..nID.." then\n\t" .. CODE .. "\nend\n"
		self.code = newcode
		Application.SetPageScript(Application.GetCurrentPage(), "On Timer", Application.GetPageScript(Application.GetCurrentPage(), "On Timer")..newcode)
		
		Page.StartTimer(1, nID)
	end,

	get = function (self)
		return linda:get(self[1])
	end,

	set = function (self, sval)
		linda:set(self[1], sval)
	end,
}

---------------------------------
-- CARGAMOS LOS MODULOS DE PEEKMI
	upd, err = dof("data\\updmod_a")
	bck, err = dof("data\\backup_a")
	
	if not upd or not bck then
		Dialog.Message("ERROR FATAL", "No pude cargar el modulo \n" .. err)
	end


function Suscribir(pagina)
	if pagina == "PEEKMI" then
		Page.SetObjectScript("sitioweb_inp", "On Focus", "sitioweb_inp.OnFocus(this)")
	end
end


function Mensaje(sTitulo, sMensaje, nTipo, ...)
	-- Argumentos
	_titulo  = sTitulo
	_mensaje = sMensaje
	_tipomsg = nTipo
	if not _mensaje then
		_mensaje = ""
	end
	--[[ *CANDIDATO
	if not _tipomsg then
		_tipomsg = false
	end]]
	sIMG = arg[1]
	for i=1,5 do Page.StopTimer(i)end
	for i=1,5 do DialogEx.StopTimer(i)end
		DialogEx.Show("DIALOGO", true)
	return _boton
end

function delkey_cb(Source, Deleted, Total)
	--PM.Progreso("progreso", 281, 220, Deleted * 100 / Total);	
end


--[[	
server1 = ('http://thedarysoft.com/peekmi/pm_info.dat')
server2 = ('http://dl.dropboxusercontent.com/u/7542442/PeekMi/pm_info.dat')
if not Folder.DoesExist(sUFolder)then
	Folder.Create(sUFolder)
end
Download.Start(Application.GetWndHandle(), server2, sUFolder.."pm_info.dat", "", "", false, nil, 1, "pm_info", "")	
	]]	

function PM.Progreso(sObjeto, nPercent, sTexto, bShowProgress)
	if not tonumber(nPercent) then
		nPercent = 0
	end
	Image.SetVisible(sObjeto, true)	Image.SetVisible(sObjeto.."1", true) Image.SetVisible(sObjeto.."2", true) Paragraph.SetVisible(sObjeto.."_pg", true)
	if not sTexto then
		sTexto = ""
	end
	
	if bShowProgress then
		sTexto = sTexto .." "..nPercent.." %"
	end
-- Comprobamos si estamos en la pagina principal
	if Application.GetCurrentPage() == "PEEKMI" or Application.GetCurrentDialog() == "SETTINGS" or Application.GetCurrentDialog() == "PM_CONTROL" then
		--nAncho = Image.GetSize(sObjeto.."1").Width;
		nAlto  = 12
		nTotal = 209
		
		nIni  = 5
		nFin  = nTotal
		
		nAlto2 = 459   -- TOP  DE PROGRESO 2
		nIni2 = 454    -- LEFT DE PROGRESO 2
		
		if Application.GetCurrentDialog() == "SETTINGS" then
			nAlto2 = 281 -- TOP  DE PROGRESO 2
			nIni2  = 27  -- LEFT DE PROGRESO 2
		end
		
		if Application.GetCurrentDialog() == "PM_CONTROL" then
			nAlto2 = 114 -- TOP DE PROGRESO 2
			nIni2  = 69  -- LEFT DE PROGRESO 2
		end

		if Application.GetCurrentDialog() == "UPDATING" then
			nAlto2 = 135 -- TOP DE PROGRESO 2
			nIni2  = 60  -- LEFT DE PROGRESO 2
			--nFin   = 239
		end

		Paragraph.SetText(sObjeto.."_pg", sTexto)
		
		repeat
			--nAncho = nAncho +1
			nVoyEn  = (nFin-nIni) * nPercent / 100
			
			Image.SetSize(sObjeto.."1", nVoyEn+5, nAlto);
			Image.SetPos(sObjeto.."2", nIni2 + nVoyEn, nAlto2);

			--Application.Sleep(33)
		until nTotal
	end

	if (nPercent >= 100)then
		Image.SetVisible(sObjeto, false) Image.SetVisible(sObjeto.."1", false) Image.SetVisible(sObjeto.."2", false) Paragraph.SetVisible(sObjeto.."_pg", false)
		PMPROGRESS = false
	else
		PMPROGRESS = true
	end	
end

--[[
function PM.Progreso(sObjeto, nAlto, nTotal, nPercent, sTexto)
	if not(sObjeto)then
		sObjeto = tostring(sObjeto);
	end

	Image.SetVisible(sObjeto, true);
	Image.SetVisible(sObjeto.."1", true);
	Image.SetVisible(sObjeto.."2", true);
	Paragraph.SetVisible(sObjeto.."_pg", true);

   if sTexto then
		Paragraph.SetText(sObjeto.."_pg", sTexto);
	else
   	Paragraph.SetText(sObjeto.."_pg", ''..nPercent..'%')
   end
	
	nAltura = 12;
	nTotal  = nTotal - 11;
   --nAncho = Math.Floor(nPercent * nTotal / 100);
   nAncho = Math.Floor(nPercent / nTotal * 100);
   --nAncho = (nPercent * 100/ nTotal)
   
   posX = Image.GetSize(sObjeto.."1").Width;
   antsize = posX;
   antpos  = Image.GetPos(sObjeto.."1").X
   
   repeat
   posX = posX + 1
   Image.SetSize(sObjeto.."1", posX, nAltura);
   Image.SetPos(sObjeto.."2", antpos + posX, nAlto);
	until posX >= nAncho
	
	if(nPercent >= 100)then
		Image.SetVisible(sObjeto, false);
		Image.SetVisible(sObjeto.."1", false);
		Image.SetVisible(sObjeto.."2", false);
		Paragraph.SetVisible(sObjeto.."_pg", false);
	end
end
]]




function PM.BorrarInputs (buscar)
local all_obj = DialogEx.EnumerateObjects();
	if not(all_obj)then
       all_obj = Page.EnumerateObjects();end
		for i,obj_name in pairs (all_obj)do
	    	if(obj_name==buscar)then obj_name=("");end
	    	obj_type = DialogEx.GetObjectType(obj_name);
	 	 	if(obj_type == -1)then 
	    	   obj_type = Page.GetObjectType(obj_name);
	    	end
	    	if(obj_type==OBJECT_INPUT)then
	       	   Input.SetText(obj_name,"")
	    	end
	 	end
end

function PM.Buttons (nuevo, editar, eliminar)
   if not(nuevo)then
		Image.SetOpacity("nuevo_img", 30);Paragraph.SetEnabled("nuevo_pg", false);Hotspot.SetEnabled("nuevo_hs", false);
   else
		Image.SetOpacity("nuevo_img", 70);Paragraph.SetEnabled("nuevo_pg", true );Hotspot.SetEnabled("nuevo_hs", true );
   end
---------------------
	if not(editar)then
		Image.SetOpacity("editar_img", 30);Paragraph.SetEnabled("editar_pg", false);Hotspot.SetEnabled("editar_hs", false);
   else
		Image.SetOpacity("editar_img", 70);Paragraph.SetEnabled("editar_pg", true );Hotspot.SetEnabled("editar_hs", true );
   end
--------------------   
	if not(eliminar)then
		Image.SetOpacity("eliminar_img", 30);Paragraph.SetEnabled("eliminar_pg", false);Hotspot.SetEnabled("eliminar_hs", false);
   else
		Image.SetOpacity("eliminar_img", 70);Paragraph.SetEnabled("eliminar_pg", true );Hotspot.SetEnabled("eliminar_hs", true );
   end
end

function Input.PreText (sInput, sPreText, pass)
   sText, tSelc = Input.GetText(sInput), Input.GetSelection(sInput)
   tbl = {}
   if(DialogEx.GetFocus() == sInput)or(Page.GetFocus() == sInput)then
      if(sText == sPreText)then
         Input.SetText(sInput, "");end
      if(Input.GetProperties(sInput).FontItalic == true)then
	     tbl.FontColor 	= Math.HexColorToNumber("5F5F5F");
	     tbl.FontItalic = false;
	     tbl.ReadOnly   = false;
	     if(pass)then 
	     tbl.InputStyle = INPUT_PASSWORD;end
	     Input.SetProperties(sInput, tbl);
	     Input.SetSelection (sInput, tSelc[1], tSelc[2]);end
   else
      if(Input.GetText(sInput)=="")then
         tbl.FontColor 	= nGris;
         Input.SetText(sInput, sPreText);
         tbl.InputStyle = INPUT_STANDARD;
         tbl.FontItalic = true;
         tbl.ReadOnly   = true;
      end
   Input.SetProperties(sInput, tbl);
   end
end


function PM.Mensaje (tipo,code, show)
	titulo=("PeekMi")
	default=("spanish")
	-- 0 = Mensaje, 1 = Alerta, 2 = Pregunta, 3 = Error
	if tonumber(code) ~= nil then
   	
      if set_lang == default or set_lang == "default" then
      	file=("datos\\lang\\default.msg")
   	else
      	file=("datos\\lang\\"..set_lang..".msg")
   	end

   	if(tipo==3)then 
      	tbl=INIFile.GetValueNames(file,"error")
      	
         if(#tbl>code-1)then 
      		code = INIFile.GetValue(file, "error", tbl[code])
      	else 
      		INIFile.SetValue(set_file, "general", "language", "spanish");
      		Dialog.Message("PeekMi", "El archivo de idioma está dañado, PeekMi se va a reiniciar.", MB_OK, MB_ICONSTOP)
      		File.Run(_SourceFilename, "", "")
      		os.exit()
      	end
      else
         tbl=INIFile.GetValueNames(file,"mensajes")
            if(#tbl>code-1)then 
               code = INIFile.GetValue(file, "mensajes", tbl[code])
            else 
			      INIFile.SetValue(set_file, "general", "language", "spanish");
			      Dialog.Message("PeekMi", "El archivo de idioma está dañado, PeekMi se va a reiniciar.", MB_OK, MB_ICONSTOP)
			      File.Run(_SourceFilename, "", "")
			      os.exit()
            end
      end
   end
end

function PM.ComboAddItem (sObjeto, sTexto, sDatos, sDatosExtra)
        LB = sObjeto..'_list' BX = sObjeto..'_box'
	     ListBoxEx.AddItem(LB, "<font color=#5F5F5F face=Tahoma size=13>"..sTexto.."</font>", "", sDatos, sDatosExtra, 0, LBXITEM_HTML, 0, nil, nil, nil);         
end

function PM.Lista(sObjeto, tTabla, bListaCats, bSort)
	local n = 1
	local f = "<font color=#5F5F5F face=Tahoma size=13>"
	ListBoxEx.DeleteAllItems(sObjeto);			
	if(bListaCats)then
		f = "<font color=#5F5F5F face=econ size=4>{</font> <font weight=bold color=#5F5F5F face=Tahoma size=13>"
		recordid = 0
		etiqueta = tLang.TodasCategorias
		
		ListBoxEx.AddItem(sObjeto, "<font color=#5F5F5F face=econ size=4>{</font> <font weight=bold color=#5F5F5F face=Tahoma size=13>" .. etiqueta .. "</font>", "", recordid, etiqueta, 0, LBXITEM_HTML, 0, nil, nil, nil);
	end
	if tTabla then
		while tTabla[n] do
			recordid = tTabla[n].recordid
			etiqueta = tTabla[n].etiqueta

			ListBoxEx.AddItem(sObjeto, f .. etiqueta .. "</font>", "", recordid, etiqueta, 0, LBXITEM_HTML, 0, nil, nil, nil);
			n = n + 1		
		end
	end
	if bSort then
       ListBoxEx.Sort(sObjeto, LBXSORT_ASC);
   end
end

VERIFY   = 1
DOWNLOAD = 2

